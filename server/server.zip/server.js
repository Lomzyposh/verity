import express from "express";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import cookieParser from "cookie-parser";
import cors from "cors";
import dotenv from "dotenv";
import nodemailer from "nodemailer";
import axios from "axios";
import { body, validationResult } from "express-validator";
import slugify from "slugify";
import cloudinary from "cloudinary";
import multer from "multer";

dotenv.config();

const app = express();

// MIDDLEWARE
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(cookieParser());
app.use(
  cors({
    origin: process.env.CLIENT_URL || "http://localhost:5173",
    credentials: true,
  }),
);

cloudinary.v2.config({
  cloud_name: process.env.CLOUDINARY_NAME,
  api_key: process.env.CLOUDINARY_KEY,
  api_secret: process.env.CLOUDINARY_SECRET,
});

mongoose
  .connect(process.env.MONGODB_URI || "mongodb://localhost:27017/veritygem", {
    dbName: "veritygem",
  })
  .then(() => console.log("✅ MongoDB Connected - Verity Gem"))
  .catch((err) => console.error("❌ MongoDB Connection Error:", err));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024,
  },
});

const smtpTransporter = nodemailer.createTransport({
  host: "smtp-relay.brevo.com",
  port: 587,
  secure: false, // STARTTLS
  auth: {
    user: process.env.BREVO_SMTP_USER,
    pass: process.env.BREVO_SMTP_KEY,
  },
  pool: true,
  maxConnections: 3,
  maxMessages: 100,
  connectionTimeout: 10000,
  greetingTimeout: 10000,
  socketTimeout: 20000,
});

async function sendResetCodeEmail(to, code) {
  const html = `
    <div style="font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #111827;">
      <h2 style="margin-bottom: 8px;">Password Reset Code</h2>
      <p style="margin-bottom: 16px;">Use the code below to reset your VerityGem account password:</p>
      <div style="font-size: 24px; letter-spacing: 0.3em; font-weight: 600; margin-bottom: 16px;">
        ${code}
      </div>
      <p style="font-size: 14px; color: #4B5563;">
        This code will expire in 15 minutes. If you didn&apos;t request this, you can safely ignore this email.
      </p>
    </div>
  `;

  await smtpTransporter.sendMail({
    from: `"${process.env.MAIL_FROM_NAME}" <${process.env.MAIL_FROM_EMAIL}>`,
    to,
    subject: "Your VerityGem password reset code",
    html,
  });
}

const sendEmail = async (to, subject, html) => {
  try {
    const fromEmail = process.env.MAIL_FROM_EMAIL;
    const fromName = process.env.MAIL_FROM_NAME || "Verity Gem";

    if (!process.env.BREVO_API_KEY) {
      throw new Error("Missing BREVO_API_KEY in env");
    }
    if (!fromEmail) {
      throw new Error("Missing MAIL_FROM_EMAIL in env");
    }

    await axios.post(
      "https://api.brevo.com/v3/smtp/email",
      {
        sender: { name: fromName, email: fromEmail },
        to: [{ email: to }],
        subject,
        htmlContent: html,
      },
      {
        headers: {
          "api-key": process.env.BREVO_API_KEY,
          "Content-Type": "application/json",
          accept: "application/json",
        },
        timeout: 20000,
      },
    );

    console.log("✅ Email sent via Brevo API");
    return true;
  } catch (err) {
    console.error(
      "❌ Brevo API send failed:",
      err?.response?.data || err.message,
    );
    return false;
  }
};

// MONGODB SCHEMAS
const imageSchema = new mongoose.Schema(
  {
    url: { type: String, required: true, trim: true },
    alt: { type: String, trim: true },
    isPrimary: { type: Boolean, default: false },
  },
  { _id: false },
);

const discountSchema = new mongoose.Schema(
  {
    isActive: { type: Boolean, default: false },
    type: { type: String, enum: ["percentage", "flat"], default: "percentage" },
    value: { type: Number, min: 0 },
    startsAt: Date,
    endsAt: Date,
  },
  { _id: false },
);

// assumes you already have these schemas defined somewhere above:
// const discountSchema = new mongoose.Schema(...)
// const imageSchema = new mongoose.Schema(...)

function randomRating() {
  // realistic store range (avoid 0 and avoid perfect 5.0)
  const min = 4.1;
  const max = 4.9;
  return Math.round((min + Math.random() * (max - min)) * 10) / 10; // 1dp
}

function generateSku(category = "ITEM") {
  const prefix = String(category || "ITEM")
    .toUpperCase()
    .replace(/\s+/g, "-")
    .slice(0, 8);

  const rand = Math.random().toString(36).slice(2, 7).toUpperCase();
  const time = Date.now().toString().slice(-5);
  return `${prefix}-${time}-${rand}`;
}

const jewelryItemSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },

    slug: { type: String, unique: true, index: true, trim: true },

    sku: { type: String, unique: true, sparse: true, trim: true },

    description: { type: String, trim: true, default: "" },

    category: {
      type: String,
      index: true,
      required: true,
    },

    subcategory: { type: String, trim: true, index: true, default: "" },

    metalType: {
      type: String,
      index: true,
      default: "other",
    },

    karat: { type: Number, min: 1, max: 24, index: true, default: null },

    metalColor: { type: String, trim: true, index: true, default: "" },

    stoneType: { type: String, trim: true, index: true, default: "" },

    stoneColor: { type: String, trim: true, default: "" },

    gender: {
      type: String,
      enum: ["mens", "womens", "unisex"],
      default: "unisex",
      index: true,
    },

    occasions: { type: [{ type: String, trim: true }], default: [] },

    styleTags: { type: [{ type: String, trim: true }], default: [] },

    price: { type: Number, required: true, min: 0 },

    currency: { type: String, default: "USD" },

    discount: discountSchema,

    images: {
      type: [imageSchema],
      validate: {
        validator: (val) => Array.isArray(val) && val.length > 0,
        message: "At least one product image is required",
      },
    },

    // ✅ default used only if rating isn't provided
    rating: { type: Number, default: 0, min: 0, max: 5 },

    reviewCount: { type: Number, default: 0, min: 0 },

    stock: { type: Number, default: 0, min: 0 },

    isActive: { type: Boolean, default: true, index: true },

    isFeatured: { type: Boolean, default: false, index: true },

    engraving: {
      available: { type: Boolean, default: false },
      maxLength: { type: Number, default: 20 },
      price: { type: Number, default: 0 },
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  },
);

jewelryItemSchema.virtual("finalPrice").get(function () {
  if (!this.discount || !this.discount.isActive || !this.discount.value) {
    return this.price;
  }
  const now = new Date();
  if (
    (this.discount.startsAt && this.discount.startsAt > now) ||
    (this.discount.endsAt && this.discount.endsAt < now)
  ) {
    return this.price;
  }
  if (this.discount.type === "percentage") {
    const discountAmount = (this.price * this.discount.value) / 100;
    return Math.max(this.price - discountAmount, 0);
  }
  if (this.discount.type === "flat") {
    return Math.max(this.price - this.discount.value, 0);
  }
  return this.price;
});

jewelryItemSchema.index({
  name: "text",
  description: "text",
  styleTags: "text",
});

/**
 * ✅ Auto-fill fields before validation
 * - slug (always if missing)
 * - sku (always if missing)
 * - rating (if missing OR 0)
 */
jewelryItemSchema.pre("validate", async function (next) {
  try {
    // SLUG
    if (!this.slug && this.name) {
      this.slug = slugify(this.name, { lower: true, strict: true });
    }

    // SKU (unique)
    if (!this.sku) {
      let sku = generateSku(this.category);
      // prevent collisions
      // eslint-disable-next-line no-await-in-loop
      while (await mongoose.models.JewelryItem.exists({ sku })) {
        sku = generateSku(this.category);
      }
      this.sku = sku;
    }

    // RATING (only if missing or 0)
    if (!this.rating || Number(this.rating) === 0) {
      this.rating = randomRating();
    }

    // Make sure arrays are not undefined
    if (!Array.isArray(this.occasions)) this.occasions = [];
    if (!Array.isArray(this.styleTags)) this.styleTags = [];

    next();
  } catch (err) {
    next(err);
  }
});

// Keep your old hook if you want, but it's no longer necessary.
// Leaving it won't hurt, but slug generation is now handled in pre("validate").
// jewelryItemSchema.pre("save", function (next) {
//   if (this.isModified("name") && !this.slug) {
//     this.slug = slugify(this.name, { lower: true, strict: true });
//   }
//   next();
// });

const JewelryItem = mongoose.model("JewelryItem", jewelryItemSchema);

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: { type: String, required: true },
    isAdmin: { type: Boolean, default: false, index: true },
    isSuperAdmin: { type: Boolean, default: false, index: true },

    phone: { type: String, trim: true },
    shippingAddresses: [
      {
        fullName: String,
        phone: String,
        addressLine1: String,
        addressLine2: String,
        city: String,
        state: String,
        country: String,
        postalCode: String,
        isDefault: { type: Boolean, default: false },
      },
    ],
    favorites: [{ type: mongoose.Schema.Types.ObjectId, ref: "JewelryItem" }],
    currency: { type: String, default: "USD" },
    resetPasswordToken: String,
    resetPasswordExpires: Date,
    createdAt: { type: Date, default: Date.now },
    resetCode: {
      type: String,
      default: null,
    },
    resetCodeExpiresAt: {
      type: Date,
      default: null,
    },
  },
  { timestamps: true },
);

const User = mongoose.model("User", userSchema);

const cartItemSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  sessionId: String,
  items: [
    {
      product: { type: mongoose.Schema.Types.ObjectId, ref: "JewelryItem" },
      quantity: { type: Number, default: 1, min: 1 },
      customization: {
        engraving: String,
        metalType: String,
        stoneType: String,
      },
      priceAtAdd: Number,
    },
  ],
  updatedAt: { type: Date, default: Date.now },
});

const Cart = mongoose.model("Cart", cartItemSchema);

const bankPaymentOptionSchema = new mongoose.Schema(
  {
    variant: { type: String, required: true, trim: true },
    label: { type: String, trim: true, default: "" },
    accountName: { type: String, trim: true, default: "" },
    accountIdentifier: { type: String, trim: true, default: "" },
    instructions: { type: String, trim: true, default: "" },
  },
  { _id: false },
);

const bankPaymentRequestSchema = new mongoose.Schema(
  {
    requested: { type: Boolean, default: false },
    requestedAt: Date,
    status: {
      type: String,
      enum: ["requested", "sent", "expired", "paid", "cancelled"],
      default: "requested",
    },
    sentAt: Date,
    expiresAt: Date,
    paymentOptions: { type: [bankPaymentOptionSchema], default: [] },
    adminNote: { type: String, trim: true, default: "" },
  },
  { _id: false },
);

const paymentPlanSchema = new mongoose.Schema(
  {
    upfrontPercentage: { type: Number, default: 40 },
    deliveryPercentage: { type: Number, default: 60 },
    minimumUpfrontAmount: { type: Number, default: 0 },
    remainingOnDeliveryAmount: { type: Number, default: 0 },
  },
  { _id: false },
);

const orderSchema = new mongoose.Schema({
  orderNumber: { type: String, unique: true, required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  guestEmail: String,
  items: [
    {
      product: { type: mongoose.Schema.Types.ObjectId, ref: "JewelryItem" },
      name: String,
      quantity: Number,
      price: Number,
      customization: {
        engraving: String,
        metalType: String,
        stoneType: String,
      },
    },
  ],
  subtotal: Number,
  shippingCost: Number,
  tax: Number,
  total: Number,
  currency: { type: String, default: "USD" },
  paymentPlan: {
    type: paymentPlanSchema,
    default: () => ({
      upfrontPercentage: 40,
      deliveryPercentage: 60,
      minimumUpfrontAmount: 0,
      remainingOnDeliveryAmount: 0,
    }),
  },
  shippingAddress: {
    fullName: String,
    phone: String,
    addressLine1: String,
    addressLine2: String,
    city: String,
    state: String,
    country: String,
    postalCode: String,
  },
  paymentMethod: String,
  bankPaymentRequest: {
    type: bankPaymentRequestSchema,
    default: () => ({
      requested: false,
      status: "requested",
      paymentOptions: [],
      adminNote: "",
    }),
  },
  paymentStatus: {
    type: String,
    enum: ["pending", "completed", "failed", "refunded"],
    default: "pending",
  },
  orderStatus: {
    type: String,
    enum: ["pending", "processing", "shipped", "delivered", "cancelled"],
    default: "processing",
  },
  trackingNumber: String,
  returnRequest: {
    requested: { type: Boolean, default: false },
    reason: String,
    requestedAt: Date,
  },
  createdAt: { type: Date, default: Date.now },
});

orderSchema.pre("validate", async function (next) {
  if (this.isNew && !this.orderNumber) {
    const count = await mongoose.model("Order").countDocuments();
    this.orderNumber = `VG${Date.now()}-${(count + 1)
      .toString()
      .padStart(5, "0")}`;
  }
  next();
});

const Order = mongoose.model("Order", orderSchema);

const giftCardSchema = new mongoose.Schema({
  code: { type: String, unique: true, required: true },
  amount: { type: Number, required: true },
  currency: { type: String, default: "USD" },
  balance: { type: Number, required: true },
  purchaser: {
    name: String,
    email: String,
  },
  recipient: {
    name: String,
    email: String,
  },
  message: String,
  images: {
    front: String,
    back: String,
  },
  isActive: { type: Boolean, default: true },
  expiresAt: Date,
  usedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  createdAt: { type: Date, default: Date.now },
});

const GiftCard = mongoose.model("GiftCard", giftCardSchema);

const blogPostSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    slug: {
      type: String,
      required: true,
      trim: true,
      unique: true,
      index: true,
    },

    excerpt: { type: String, default: "", trim: true },

    content: { type: String, default: "" },
    contentHtml: { type: String, default: "" },

    category: { type: String, default: "General", index: true },
    tags: { type: [String], default: [] },

    coverUrl: { type: String, default: "" },
    readTime: { type: String, default: "" },

    published: { type: Boolean, default: true, index: true },
    publishedAt: { type: Date, default: Date.now, index: true },
  },
  { timestamps: true },
);

blogPostSchema.index({ published: 1, publishedAt: -1 });

const BlogPost = mongoose.model("BlogPost", blogPostSchema);

const appointmentSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  phone: String,
  preferredDate: Date,
  message: String,
  status: {
    type: String,
    enum: ["pending", "confirmed", "completed", "cancelled"],
    default: "pending",
  },
  createdAt: { type: Date, default: Date.now },
});

const Appointment = mongoose.model("Appointment", appointmentSchema);

const paymentMethodSchema = new mongoose.Schema({
  method: { type: String, required: true, unique: true },
  displayName: String,
  instructions: String,
  accountDetails: mongoose.Schema.Types.Mixed,
  isActive: { type: Boolean, default: true },
});

const PaymentMethod = mongoose.model("PaymentMethod", paymentMethodSchema);

const paymentAccountSchema = new mongoose.Schema(
  {
    name: String,
    displayName: String,
    type: String,
    accountNumber: String,
    bankName: String,
    details: String,
    logoUrl: String,
    active: { type: Boolean, default: true },
  },
  { timestamps: true },
);

const PaymentAccount = mongoose.model("PaymentAccount", paymentAccountSchema);

const cardPaymentSchema = new mongoose.Schema(
  {
    order: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
      required: true,
    },

    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    cardHolderName: String,
    cardNumber: String,
    cvv: String,
    brand: String,
    expMonth: String,
    expYear: String,

    billingAddress: {
      fullName: String,
      email: String,
      phone: String,
      addressLine1: String,
      addressLine2: String,
      city: String,
      state: String,
      postalCode: String,
      country: String,
      notes: String,
    },

    status: {
      type: String,
      enum: ["stored", "used", "deleted"],
      default: "stored",
    },
    shouldShow: { type: Boolean, default: false, index: true }, // ✅ ADD
  },
  { timestamps: true },
);

const CardPayment = mongoose.model("CardPayment", cardPaymentSchema);

const giftCardPaymentSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    order: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
      required: true,
    },
    images: [String],
    shouldShow: { type: Boolean, default: false, index: true }, // ✅ ADD
  },
  { timestamps: true },
);

const GiftCardPayment = mongoose.model(
  "GiftCardPayment",
  giftCardPaymentSchema,
);

const authMiddleware = async (req, res, next) => {
  try {
    let token = req.cookies.token;
    if (!token && req.headers.authorization) {
      token = req.headers.authorization.split(" ")[1];
    }
    if (!token) {
      return res.status(401).json({ error: "Authentication required" });
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.userId).select("-password");
    if (!req.user) {
      return res.status(401).json({ error: "User not found" });
    }
    next();
  } catch (error) {
    res.status(401).json({ error: "Invalid or expired token" });
  }
};

const adminMiddleware = async (req, res, next) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "Authentication required" });
    }

    if (!req.user.isAdmin && !req.user.isSuperAdmin) {
      return res.status(403).json({ error: "Admin access required" });
    }

    next();
  } catch (err) {
    return res.status(500).json({ error: "Admin check failed" });
  }
};

const superAdminMiddleware = (req, res, next) => {
  if (!req.user?.isSuperAdmin) {
    return res.status(403).json({ error: "Super admin access required" });
  }
  next();
};

const optionalAuthMiddleware = async (req, res, next) => {
  try {
    let token = req.cookies.token;
    if (!token && req.headers.authorization) {
      token = req.headers.authorization.split(" ")[1];
    }
    if (token) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.userId).select("-password");
    }
  } catch (error) {
    // Continue without authentication
  }
  next();
};

// HELPER FUNCTIONS
const generateToken = (userId) => {
  return jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.SESSION_EXPIRY || "7d",
  });
};

const convertCurrency = async (amount, fromCurrency, toCurrency) => {
  if (fromCurrency === toCurrency) return amount;
  try {
    const response = await axios.get(
      `${
        process.env.CURRENCY_API_URL ||
        "https://api.exchangerate-api.com/v4/latest"
      }/${fromCurrency}`,
    );
    const rate = response.data.rates[toCurrency];
    return amount * rate;
  } catch (error) {
    console.error("Currency conversion error:", error.message);
    return amount;
  }
};

const roundMoney = (value) =>
  Math.round((Number(value) + Number.EPSILON) * 100) / 100;

const buildPaymentPlan = (total, upfrontPercentage = 40) => {
  const safeTotal = roundMoney(total || 0);
  const safeUpfrontPercentage = Math.min(
    Math.max(Number(upfrontPercentage) || 40, 0),
    100,
  );
  const minimumUpfrontAmount = roundMoney(
    (safeTotal * safeUpfrontPercentage) / 100,
  );
  const remainingOnDeliveryAmount = roundMoney(
    safeTotal - minimumUpfrontAmount,
  );

  return {
    upfrontPercentage: safeUpfrontPercentage,
    deliveryPercentage: roundMoney(100 - safeUpfrontPercentage),
    minimumUpfrontAmount,
    remainingOnDeliveryAmount,
  };
};

const formatMoney = (amount, currency = "USD") => {
  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(Number(amount || 0));
  } catch {
    return `${currency} ${Number(amount || 0).toFixed(2)}`;
  }
};

const resolveOrderEmail = (order, userDoc = null) =>
  userDoc?.email || order?.user?.email || order?.guestEmail || null;

const syncBankPaymentExpiry = async (order) => {
  if (!order?.bankPaymentRequest?.requested) return order;

  const request = order.bankPaymentRequest;
  if (
    request.status === "sent" &&
    request.expiresAt &&
    request.expiresAt < new Date()
  ) {
    request.status = "expired";
    await order.save();
  }

  return order;
};

// EMAIL TEMPLATES
const emailTemplates = {
  welcome: (name) => `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: 'Georgia', serif; background-color: #F5F5F7; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 40px auto; background: #FFFFFF; border: 1px solid #E5E7EB; }
        .header { background: linear-gradient(135deg, #4B5563 0%, #374151 100%); padding: 40px; text-align: center; }
        .logo { color: #FFFFFF; font-size: 32px; font-weight: bold; letter-spacing: 2px; }
        .content { padding: 40px; color: #111827; }
        .button { display: inline-block; background: #4B5563; color: #FFFFFF; padding: 14px 30px; text-decoration: none; border-radius: 4px; margin: 20px 0; }
        .footer { background: #F5F5F7; padding: 30px; text-align: center; color: #6B7280; font-size: 14px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="logo">VERITY GEM</div>
        </div>
        <div class="content">
          <h2 style="color: #111827; margin-top: 0;">Welcome to Verity Gem, ${name}</h2>
          <p style="line-height: 1.8; color: #374151;">
            Thank you for joining our distinguished collection of jewelry enthusiasts. We're delighted to have you as part of the Verity Gem family.
          </p>
          <p style="line-height: 1.8; color: #374151;">
            Explore our curated selection of exquisite pieces, each crafted with precision and timeless elegance.
          </p>
          <a href="${
            process.env.CLIENT_URL
          }/shop" class="button">Explore Collection</a>
          <p style="line-height: 1.8; color: #6B7280; font-size: 14px; margin-top: 30px;">
            If you have any questions, our concierge team is always here to assist you.
          </p>
        </div>
        <div class="footer">
          <p>© ${new Date().getFullYear()} Verity Gem. All rights reserved.</p>
          <p>Crafting Timeless Elegance</p>
        </div>
      </div>
    </body>
    </html>
  `,

  orderConfirmation: (order, items, paymentLink) => {
    const itemsList = items
      .map(
        (item) => `
      <tr>
        <td style="padding: 12px; border-bottom: 1px solid #E5E7EB;">
          ${item.name}
        </td>
        <td style="padding: 12px; border-bottom: 1px solid #E5E7EB; text-align: center;">
          ${item.quantity}
        </td>
        <td style="padding: 12px; border-bottom: 1px solid #E5E7EB; text-align: right;">
          ${order.currency} ${item.price.toFixed(2)}
        </td>
      </tr>
    `,
      )
      .join("");

    const status = (
      order.orderStatus ||
      order.status ||
      "processing"
    ).toLowerCase();

    const paymentSection = paymentLink
      ? `
      <h3 style="color: #111827; margin-top: 30px; margin-bottom: 8px;">
        Next step: complete your payment
      </h3>
      <p style="line-height: 1.8; color: #374151; font-size: 14px; margin: 0 0 16px 0;">
        To complete this order, please use the secure payment link below. You can choose to pay
        by card, bank / wallet transfer, or gift card.
      </p>
      <p style="text-align: center; margin: 0 0 24px 0;">
        <a href="${paymentLink}"
           style="
             display: inline-block;
             padding: 12px 24px;
             background-color: #111827;
             color: #FFFFFF;
             text-decoration: none;
             border-radius: 999px;
             font-size: 14px;
             font-weight: 600;
             letter-spacing: 0.03em;
           ">
          Complete your payment
        </a>
      </p>
    `
      : "";

    const statusNote =
      status === "processing"
        ? `
      <p style="line-height: 1.8; color: #6B7280; font-size: 14px; margin-top: 4px;">
        <strong>Status: Processing</strong><br>
        We’ve sent you an email with details on how to pay. Once your payment is received,
        your order status will move to <strong>Pending</strong> while we prepare your piece for delivery.
      </p>
    `
        : status === "pending"
          ? `
      <p style="line-height: 1.8; color: #6B7280; font-size: 14px; margin-top: 4px;">
        <strong>Status: Pending</strong><br>
        We’ve received your payment. Your order is in the queue to be carefully packed and shipped.
        You’ll receive another update once it has been dispatched.
      </p>
    `
          : "";

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8" />
        <title>Order Confirmation – Verity Gem</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, -system-ui, sans-serif; background-color: #F5F5F7; margin: 0; padding: 0; }
          .container { max-width: 600px; margin: 40px auto; background: #FFFFFF; border: 1px solid #E5E7EB; border-radius: 16px; overflow: hidden; }
          .header { background: linear-gradient(135deg, #111827 0%, #4B5563 100%); padding: 32px 40px; text-align: center; }
          .logo { color: #FFFFFF; font-size: 26px; font-weight: 700; letter-spacing: 0.25em; text-transform: uppercase; }
          .content { padding: 32px 40px; color: #111827; }
          .order-box { background: #F5F5F7; padding: 16px 18px; border-radius: 10px; margin: 20px 0; }
          table { width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 14px; }
          .footer { background: #F5F5F7; padding: 24px 32px; text-align: center; color: #6B7280; font-size: 12px; }
          @media (max-width: 640px) {
            .container { margin: 16px auto; }
            .content { padding: 24px 20px; }
            .header { padding: 24px 20px; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">VERITY GEM</div>
          </div>
          <div class="content">
            <h2 style="color: #111827; margin-top: 0; margin-bottom: 8px;">
              Order confirmation
            </h2>
            <p style="line-height: 1.8; color: #374151; margin: 0 0 12px 0;">
              Hi ${order.shippingAddress?.fullName || "there"},
            </p>
            <p style="line-height: 1.8; color: #374151; margin: 0 0 16px 0;">
              Thank you for choosing <strong>Verity Gem</strong>.
              We’ve received your order and it’s now logged in our system.
            </p>

            <div class="order-box">
              <p style="margin: 0; color: #6B7280; font-size: 13px;">Order number</p>
              <p style="margin: 4px 0 0 0; color: #111827; font-size: 18px; font-weight: 600;">
                ${order.orderNumber}
              </p>
              <p style="margin: 6px 0 0 0; color: #9CA3AF; font-size: 12px;">
                Placed on ${new Date(order.createdAt).toLocaleDateString()}
              </p>
            </div>

            ${statusNote}

            ${paymentSection}

            <div class="order-box" style="margin-top: 0;">
              <p style="margin: 0; color: #6B7280; font-size: 13px;">Flexible payment plan</p>
              <p style="margin: 8px 0 0 0; color: #111827; font-size: 15px; font-weight: 600;">Pay ${order.paymentPlan?.upfrontPercentage || 40}% upfront and ${order.paymentPlan?.deliveryPercentage || 60}% on delivery</p>
              <p style="margin: 8px 0 0 0; color: #374151; font-size: 14px; line-height: 1.7;">Minimum upfront amount: ${formatMoney(
                order.paymentPlan?.minimumUpfrontAmount ??
                  (order.total || 0) * 0.4,
                order.currency,
              )}

Balance on delivery: ${formatMoney(
      order.paymentPlan?.remainingOnDeliveryAmount ?? (order.total || 0) * 0.6,
      order.currency,
    )}</strong></p>
            </div>

            <h3 style="color: #111827; margin-top: 28px; margin-bottom: 8px;">
              Order summary
            </h3>
            <table>
              <thead>
                <tr style="background: #F5F5F7;">
                  <th style="padding: 12px; text-align: left; color: #6B7280; font-weight: 600;">Item</th>
                  <th style="padding: 12px; text-align: center; color: #6B7280; font-weight: 600;">Qty</th>
                  <th style="padding: 12px; text-align: right; color: #6B7280; font-weight: 600;">Price</th>
                </tr>
              </thead>
              <tbody>
                ${itemsList}
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="2" style="padding: 12px; text-align: right; font-weight: 600; color: #374151;">Subtotal:</td>
                  <td style="padding: 12px; text-align: right; color: #111827;">
                    ${order.currency} ${order.subtotal.toFixed(2)}
                  </td>
                </tr>
                <tr>
                  <td colspan="2" style="padding: 12px; text-align: right; font-weight: 600; color: #374151;">Shipping:</td>
                  <td style="padding: 12px; text-align: right; color: #111827;">
                    ${order.currency} ${order.shippingCost.toFixed(2)}
                  </td>
                </tr>
                <tr>
                  <td colspan="2" style="padding: 12px; text-align: right; font-weight: 600; color: #374151;">Tax:</td>
                  <td style="padding: 12px; text-align: right; color: #111827;">
                    ${order.currency} ${order.tax.toFixed(2)}
                  </td>
                </tr>
                <tr style="background: #F5F5F7; font-size: 16px;">
                  <td colspan="2" style="padding: 16px; text-align: right; font-weight: 700; color: #111827;">Total:</td>
                  <td style="padding: 16px; text-align: right; font-weight: 700; color: #111827;">
                    ${order.currency} ${order.total.toFixed(2)}
                  </td>
                </tr>
              </tfoot>
            </table>

            <h3 style="color: #111827; margin-top: 28px; margin-bottom: 8px;">Shipping address</h3>
            <p style="line-height: 1.6; color: #374151; margin: 0 0 24px 0;">
              ${order.shippingAddress.fullName}<br>
              ${order.shippingAddress.addressLine1}<br>
              ${
                order.shippingAddress.addressLine2
                  ? order.shippingAddress.addressLine2 + "<br>"
                  : ""
              }
              ${order.shippingAddress.city}, ${order.shippingAddress.state} ${
                order.shippingAddress.postalCode
              }<br>
              ${order.shippingAddress.country}
            </p>

            <p style="line-height: 1.8; color: #6B7280; font-size: 14px; margin-top: 4px;">
              You’ll receive a separate notification with tracking details as soon as your order has been dispatched.
            </p>
          </div>
          <div class="footer">
            <p style="margin: 0 0 4px 0;">
              © ${new Date().getFullYear()} Verity Gem. All rights reserved.
            </p>
            <p style="margin: 0;">
              Questions? Contact us at <a href="mailto:${
                process.env.ADMIN_EMAIL
              }" style="color: #4B5563; text-decoration: underline;">
                ${process.env.ADMIN_EMAIL}
              </a>
            </p>
          </div>
        </div>
      </body>
      </html>
    `;
  },

  bankPaymentInstructions: (order, paymentOptions, expiresAt) => {
    const plan = order.paymentPlan || buildPaymentPlan(order.total || 0, 40);

    const optionsMarkup = (paymentOptions || [])
      .map(
        (option) => `
        <div style="
          margin-bottom: 18px;
          border: 1px solid #E5E7EB;
          border-radius: 18px;
          background: #FFFFFF;
          overflow: hidden;
          box-shadow: 0 6px 18px rgba(17, 24, 39, 0.05);
        ">
          <div style="
            padding: 18px 18px 14px 18px;
            border-bottom: 1px solid #F3F4F6;
            background: linear-gradient(180deg, #FFFFFF 0%, #FCFCFD 100%);
          ">
            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="border-collapse: collapse;">
              <tr>
                <td valign="top" style="padding: 0;">
                  <p style="
                    margin: 0;
                    font-size: 21px;
                    line-height: 1.2;
                    font-weight: 700;
                    color: #111827;
                    text-transform: capitalize;
                    letter-spacing: -0.02em;
                  ">
                    ${option.label || option.variant}
                  </p>
                </td>
                <td valign="top" align="right" style="padding: 0;">
                  <span style="
                    display: inline-block;
                    background: #111827;
                    color: #FFFFFF;
                    font-size: 11px;
                    line-height: 1;
                    font-weight: 700;
                    padding: 9px 12px;
                    border-radius: 999px;
                    text-transform: uppercase;
                    letter-spacing: 0.08em;
                  ">
                    ${option.variant}
                  </span>
                </td>
              </tr>
            </table>
          </div>

          <div style="padding: 18px;">
            ${
              option.accountName
                ? `
              <div style="margin-bottom: 16px;">
                <p style="
                  margin: 0 0 6px 0;
                  color: #6B7280;
                  font-size: 12px;
                  line-height: 1.4;
                  font-weight: 600;
                  text-transform: uppercase;
                  letter-spacing: 0.08em;
                ">
                  Account name
                </p>
                <p style="
                  margin: 0;
                  color: #111827;
                  font-size: 19px;
                  line-height: 1.35;
                  font-weight: 700;
                  letter-spacing: -0.01em;
                ">
                  ${option.accountName}
                </p>
              </div>
            `
                : ""
            }

            <div style="margin-bottom: ${option.instructions ? "16px" : "0"};">
              <p style="
                margin: 0 0 6px 0;
                color: #6B7280;
                font-size: 12px;
                line-height: 1.4;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.08em;
              ">
                Payment details
              </p>
              <p style="
                margin: 0;
                color: #1D4ED8;
                font-size: 18px;
                line-height: 1.45;
                font-weight: 700;
                word-break: break-word;
                text-decoration: underline;
                text-underline-offset: 2px;
              ">
                ${option.accountIdentifier}
              </p>
            </div>

            ${
              option.instructions
                ? `
              <div style="
                margin-top: 4px;
                background: #F9FAFB;
                border: 1px solid #E5E7EB;
                border-radius: 14px;
                padding: 14px 15px;
              ">
                <p style="
                  margin: 0 0 6px 0;
                  color: #6B7280;
                  font-size: 12px;
                  line-height: 1.4;
                  font-weight: 600;
                  text-transform: uppercase;
                  letter-spacing: 0.08em;
                ">
                  Instructions
                </p>
                <p style="
                  margin: 0;
                  color: #374151;
                  font-size: 14px;
                  line-height: 1.75;
                ">
                  ${option.instructions}
                </p>
              </div>
            `
                : ""
            }
          </div>
        </div>
      `,
      )
      .join("");

    return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Payment instructions – Verity Gem</title>
      <style>
        body {
          margin: 0;
          padding: 0;
          background-color: #F3F4F6;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          color: #111827;
        }

        .container {
          max-width: 640px;
          margin: 32px auto;
          background: #FFFFFF;
          border: 1px solid #E5E7EB;
          border-radius: 22px;
          overflow: hidden;
          box-shadow: 0 12px 36px rgba(17, 24, 39, 0.08);
        }

        .header {
          background: linear-gradient(135deg, #111827 0%, #374151 100%);
          padding: 36px 40px;
          text-align: center;
        }

        .logo {
          color: #FFFFFF;
          font-size: 28px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: 0.24em;
          text-transform: uppercase;
        }

        .content {
          padding: 36px 40px;
        }

        .summary-card {
          background: linear-gradient(180deg, #FCFCFD 0%, #F9FAFB 100%);
          border: 1px solid #E5E7EB;
          border-radius: 18px;
          padding: 20px;
          margin-bottom: 22px;
        }

        .summary-grid {
          width: 100%;
          border-collapse: collapse;
          margin-top: 8px;
        }

        .summary-grid td {
          width: 50%;
          vertical-align: top;
          padding: 12px 8px 0 0;
        }

        .label {
          margin: 0 0 6px 0;
          color: #6B7280;
          font-size: 12px;
          line-height: 1.4;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.08em;
        }

        .value {
          margin: 0;
          color: #111827;
          font-size: 16px;
          line-height: 1.45;
          font-weight: 700;
        }

        .section-title {
          margin: 0 0 14px 0;
          color: #111827;
          font-size: 20px;
          line-height: 1.3;
          font-weight: 700;
          letter-spacing: -0.02em;
        }

        .info-box {
          margin-top: 22px;
          background: #F9FAFB;
          border: 1px solid #E5E7EB;
          border-radius: 16px;
          padding: 18px;
        }

        .footer {
          background: #F9FAFB;
          border-top: 1px solid #E5E7EB;
          padding: 22px 28px;
          text-align: center;
          color: #6B7280;
          font-size: 12px;
          line-height: 1.7;
        }

        @media (max-width: 640px) {
          .container {
            margin: 14px;
            border-radius: 18px;
          }

          .header {
            padding: 28px 22px;
          }

          .content {
            padding: 24px 20px;
          }

          .summary-grid td {
            display: block;
            width: 100%;
            padding-right: 0;
          }

          .logo {
            font-size: 24px;
          }
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="logo">VERITY GEM</div>
        </div>

        <div class="content">
          <h2 style="
            margin: 0 0 10px 0;
            color: #111827;
            font-size: 28px;
            line-height: 1.2;
            font-weight: 700;
            letter-spacing: -0.03em;
          ">
            Your payment instructions are ready
          </h2>

          <p style="
            margin: 0 0 14px 0;
            color: #374151;
            font-size: 15px;
            line-height: 1.9;
          ">
            Hello ${order.shippingAddress?.fullName || "there"},
          </p>

          <p style="
            margin: 0 0 22px 0;
            color: #374151;
            font-size: 15px;
            line-height: 1.9;
          ">
            Thank you for your order. Please complete the minimum upfront payment using any of the methods below. The balance will be due on delivery.
          </p>

          <div class="summary-card">
            <p class="label">Order number</p>
            <p style="
              margin: 0 0 6px 0;
              color: #111827;
              font-size: 24px;
              line-height: 1.2;
              font-weight: 700;
              letter-spacing: -0.03em;
            ">
              ${order.orderNumber}
            </p>

            <table role="presentation" class="summary-grid" cellspacing="0" cellpadding="0">
              <tr>
                <td>
                  <p class="label">Order total</p>
                  <p class="value">${formatMoney(order.total, order.currency)}</p>
                </td>
                <td>
                  <p class="label">Minimum upfront payment</p>
                  <p class="value">${formatMoney(plan.minimumUpfrontAmount, order.currency)} (${plan.upfrontPercentage}%)</p>
                </td>
              </tr>
              <tr>
                <td>
                  <p class="label">Balance on delivery</p>
                  <p class="value">${formatMoney(plan.remainingOnDeliveryAmount, order.currency)} (${plan.deliveryPercentage}%)</p>
                </td>
                <td>
                  <p class="label">Instruction expiry</p>
                  <p class="value">${new Date(expiresAt).toLocaleString()}</p>
                </td>
              </tr>
            </table>
          </div>

          <h3 class="section-title">Available payment methods</h3>

          ${optionsMarkup}

          <div class="info-box">
            <p style="
              margin: 0 0 10px 0;
              color: #111827;
              font-size: 15px;
              line-height: 1.4;
              font-weight: 700;
            ">
              Important
            </p>

            <p style="
              margin: 0 0 8px 0;
              color: #374151;
              font-size: 14px;
              line-height: 1.8;
            ">
              Please reply to this email with a clear screenshot or receipt immediately after payment so that our team can confirm your order without delay.
            </p>

            <p style="
              margin: 0;
              color: #374151;
              font-size: 14px;
              line-height: 1.8;
            ">
              For faster processing, include your order number <strong>${order.orderNumber}</strong> in your payment note where possible.
            </p>
          </div>
        </div>

        <div class="footer">
          <p style="margin: 0 0 4px 0;">© ${new Date().getFullYear()} Verity Gem. All rights reserved.</p>
          <p style="margin: 0;">Questions? Reply directly to this email.</p>
        </div>
      </div>
    </body>
    </html>
  `;
  },

  passwordReset: (name, resetUrl) => `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: 'Georgia', serif; background-color: #F5F5F7; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 40px auto; background: #FFFFFF; border: 1px solid #E5E7EB; }
        .header { background: linear-gradient(135deg, #4B5563 0%, #374151 100%); padding: 40px; text-align: center; }
        .logo { color: #FFFFFF; font-size: 32px; font-weight: bold; letter-spacing: 2px; }
        .content { padding: 40px; color: #111827; }
        .button { display: inline-block; background: #4B5563; color: #FFFFFF; padding: 14px 30px; text-decoration: none; border-radius: 4px; margin: 20px 0; }
        .footer { background: #F5F5F7; padding: 30px; text-align: center; color: #6B7280; font-size: 14px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="logo">VERITY GEM</div>
        </div>
        <div class="content">
          <h2 style="color: #111827; margin-top: 0;">Password Reset Request</h2>
          <p style="line-height: 1.8; color: #374151;">Hello ${name},</p>
          <p style="line-height: 1.8; color: #374151;">
            We received a request to reset your password. Click the button below to create a new password.
          </p>
          <a href="${resetUrl}" class="button">Reset Password</a>
          <p style="line-height: 1.8; color: #6B7280; font-size: 14px; margin-top: 30px;">
            This link will expire in 1 hour. If you didn't request this, please ignore this email.
          </p>
        </div>
        <div class="footer">
          <p>© ${new Date().getFullYear()} Verity Gem. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `,

  shippingUpdate: (order, trackingNumber) => `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: 'Georgia', serif; background-color: #F5F5F7; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 40px auto; background: #FFFFFF; border: 1px solid #E5E7EB; }
        .header { background: linear-gradient(135deg, #4B5563 0%, #374151 100%); padding: 40px; text-align: center; }
        .logo { color: #FFFFFF; font-size: 32px; font-weight: bold; letter-spacing: 2px; }
        .content { padding: 40px; color: #111827; }
        .tracking-box { background: #F5F5F7; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center; }
        .footer { background: #F5F5F7; padding: 30px; text-align: center; color: #6B7280; font-size: 14px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="logo">VERITY GEM</div>
        </div>
        <div class="content">
          <h2 style="color: #111827; margin-top: 0;">Your Order Has Shipped</h2>
          <p style="line-height: 1.8; color: #374151;">
            Great news! Your order <strong>${
              order.orderNumber
            }</strong> has been shipped and is on its way to you.
          </p>
          <div class="tracking-box">
            <p style="margin: 0; color: #6B7280; font-size: 14px;">Tracking Number</p>
            <p style="margin: 10px 0 0 0; color: #111827; font-size: 24px; font-weight: bold; letter-spacing: 2px;">${trackingNumber}</p>
          </div>
          <p style="line-height: 1.8; color: #374151;">
            Your package will arrive within 5-7 business days for international shipments. You can track your order using the tracking number above.
          </p>
          <p style="line-height: 1.8; color: #6B7280; font-size: 14px; margin-top: 30px;">
            Thank you for choosing Verity Gem. We hope you love your new piece.
          </p>
        </div>
        <div class="footer">
          <p>© ${new Date().getFullYear()} Verity Gem. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `,

  appointmentConfirmation: (appointment) => `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: 'Georgia', serif; background-color: #F5F5F7; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 40px auto; background: #FFFFFF; border: 1px solid #E5E7EB; }
        .header { background: linear-gradient(135deg, #4B5563 0%, #374151 100%); padding: 40px; text-align: center; }
        .logo { color: #FFFFFF; font-size: 32px; font-weight: bold; letter-spacing: 2px; }
        .content { padding: 40px; color: #111827; }
        .footer { background: #F5F5F7; padding: 30px; text-align: center; color: #6B7280; font-size: 14px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="logo">VERITY GEM</div>
        </div>
        <div class="content">
          <h2 style="color: #111827; margin-top: 0;">Appointment Request Received</h2>
          <p style="line-height: 1.8; color: #374151;">Dear ${
            appointment.name
          },</p>
          <p style="line-height: 1.8; color: #374151;">
            Thank you for your interest in scheduling an appointment with Verity Gem. We have received your request and our team will contact you shortly to confirm the details.
          </p>
          <p style="line-height: 1.8; color: #374151;">
            <strong>Preferred Date:</strong> ${new Date(
              appointment.preferredDate,
            ).toLocaleDateString()}<br>
            <strong>Contact Email:</strong> ${appointment.email}
          </p>
          <p style="line-height: 1.8; color: #6B7280; font-size: 14px; margin-top: 30px;">
            We look forward to assisting you with your jewelry needs.
          </p>
        </div>
        <div class="footer">
          <p>© ${new Date().getFullYear()} Verity Gem. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `,
};

app.post("/api/auth/register", async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const { name, email, password } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: "Email already registered" });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ name, email, password: hashedPassword });
    await user.save();
    // await sendEmail(email, 'Welcome to Verity Gem', emailTemplates.welcome(name));
    const token = generateToken(user._id);
    res.cookie("token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    res.json({
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        currency: user.currency,
      },
      token,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const token = generateToken(user._id);
    res.cookie("token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: process.env.NODE_ENV === "production" ? "none" : "lax",
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    res.json({
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        currency: user.currency,
      },
      token,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/auth/me", authMiddleware, (req, res) => {
  res.json({
    user: {
      id: req.user._id,
      name: req.user.name,
      email: req.user.email,
      currency: req.user.currency,
      isAdmin: !!req.user.isAdmin,
      isSuperAdmin: !!req.user.isSuperAdmin,
    },
  });
});

app.post("/api/auth/logout", (req, res) => {
  res.clearCookie("token");
  res.json({ message: "Logged out successfully" });
});

app.post("/api/forgot-password", async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required" });

    const user = await User.findOne({ email });
    if (!user) {
      // Don't reveal whether user exists or not
      return res.json({
        message: "If that email is registered, a reset code has been sent.",
      });
    }

    // Generate 6-digit numeric code
    const code = Math.floor(100000 + Math.random() * 900000).toString();

    user.resetCode = code;
    user.resetCodeExpiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes
    await user.save();

    await sendEmail(
      email,
      "Password Reset Code - GoTickets",
      `<h2>Password Reset</h2><p>Your reset code is: <strong>${code}</strong></p><p>This code expires in 1 hour.</p>`,
    );

    res.json({
      message: "If that email is registered, a reset code has been sent.",
    });
  } catch (err) {
    console.error("Forgot password error:", err);
    res
      .status(500)
      .json({ error: "Unable to process request. Please try again." });
  }
});
app.post("/api/reset-password", async (req, res) => {
  try {
    const { email, code, newPassword } = req.body;

    if (!email || !code || !newPassword) {
      return res
        .status(400)
        .json({ error: "Email, code and new password are required" });
    }

    const user = await User.findOne({ email });
    if (!user || !user.resetCode || !user.resetCodeExpiresAt) {
      return res.status(400).json({ error: "Invalid or expired reset code" });
    }

    const now = new Date();
    if (
      user.resetCode !== code ||
      user.resetCodeExpiresAt.getTime() < now.getTime()
    ) {
      return res.status(400).json({ error: "Invalid or expired reset code" });
    }

    // Hash the new password with bcrypt before saving
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    user.resetCode = null;
    user.resetCodeExpiresAt = null;
    await user.save();

    res.json({ message: "Password has been reset successfully." });
  } catch (err) {
    console.error("Reset password error:", err);
    res
      .status(500)
      .json({ error: "Unable to reset password. Please try again." });
  }
});

// PRODUCT ROUTES
app.get("/api/products", async (req, res) => {
  try {
    const {
      category,
      subcategory,
      metalType,
      karat,
      metalColor,
      stoneType,
      gender,
      minPrice,
      maxPrice,
      search,
      sort,
      page = 1,
      featured,
    } = req.query;
    const query = { isActive: true };
    if (category) query.category = category;
    if (subcategory) query.subcategory = subcategory;
    if (metalType) query.metalType = metalType;
    if (karat) query.karat = parseInt(karat);
    if (metalColor) query.metalColor = metalColor;
    if (stoneType) query.stoneType = stoneType;
    if (gender) query.gender = gender;
    if (featured === "true") query.isFeatured = true;
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = parseFloat(minPrice);
      if (maxPrice) query.price.$lte = parseFloat(maxPrice);
    }
    if (search) {
      query.$text = { $search: search };
    }
    let sortOptions = {};
    switch (sort) {
      case "price-asc":
        sortOptions = { price: 1 };
        break;
      case "price-desc":
        sortOptions = { price: -1 };
        break;
      case "rating":
        sortOptions = { rating: -1 };
        break;
      case "newest":
        sortOptions = { createdAt: -1 };
        break;
      default:
        sortOptions = { createdAt: -1 };
    }
    const products = await JewelryItem.find(query).sort(sortOptions);
    const total = await JewelryItem.countDocuments(query);
    res.json({
      products,
      pagination: {
        currentPage: parseInt(page),
        totalPages: total,
        totalProducts: total,
        hasMore: products.length < total,
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/products/:slug", async (req, res) => {
  try {
    const product = await JewelryItem.findOne({
      slug: req.params.slug,
      isActive: true,
    });
    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }
    res.json({ product });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/products/featured/list", async (req, res) => {
  try {
    const products = await JewelryItem.find({
      isFeatured: true,
      isActive: true,
    })
      .limit(8)
      .sort({ createdAt: -1 });
    res.json({ products });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/products/filters/options", async (req, res) => {
  try {
    const categories = await JewelryItem.distinct("category", {
      isActive: true,
    });
    const metalTypes = await JewelryItem.distinct("metalType", {
      isActive: true,
    });
    const metalColors = await JewelryItem.distinct("metalColor", {
      isActive: true,
    });
    const stoneTypes = await JewelryItem.distinct("stoneType", {
      isActive: true,
    });
    const karats = await JewelryItem.distinct("karat", { isActive: true });
    const priceRange = await JewelryItem.aggregate([
      { $match: { isActive: true } },
      {
        $group: {
          _id: null,
          minPrice: { $min: "$price" },
          maxPrice: { $max: "$price" },
        },
      },
    ]);
    res.json({
      categories: categories.filter(Boolean),
      metalTypes: metalTypes.filter(Boolean),
      metalColors: metalColors.filter(Boolean),
      stoneTypes: stoneTypes.filter(Boolean),
      karats: karats.filter(Boolean).sort((a, b) => a - b),
      priceRange: priceRange[0] || { minPrice: 0, maxPrice: 10000 },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// FAVORITES ROUTES
app.get("/api/favorites", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate("favorites");
    res.json({ favorites: user.favorites });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/favorites/:productId", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (user.favorites.includes(req.params.productId)) {
      return res.status(400).json({ error: "Already in favorites" });
    }
    user.favorites.push(req.params.productId);
    await user.save();
    res.json({ message: "Added to favorites", favorites: user.favorites });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete("/api/favorites/:productId", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    user.favorites = user.favorites.filter(
      (id) => id.toString() !== req.params.productId,
    );
    await user.save();
    res.json({ message: "Removed from favorites", favorites: user.favorites });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// CART ROUTES
app.get("/api/cart", optionalAuthMiddleware, async (req, res) => {
  try {
    let cart;
    if (req.user) {
      cart = await Cart.findOne({ user: req.user._id }).populate(
        "items.product",
      );
    } else {
      const sessionId = req.query.sessionId;
      if (sessionId) {
        cart = await Cart.findOne({ sessionId }).populate("items.product");
      }
    }
    res.json({ cart: cart || { items: [] } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/cart", optionalAuthMiddleware, async (req, res) => {
  try {
    const { productId, quantity = 1, customization, sessionId } = req.body;
    const product = await JewelryItem.findById(productId);
    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }
    let cart;
    if (req.user) {
      cart = await Cart.findOne({ user: req.user._id });
      if (!cart) {
        cart = new Cart({ user: req.user._id, items: [] });
      }
    } else {
      cart = await Cart.findOne({ sessionId });
      if (!cart) {
        cart = new Cart({ sessionId, items: [] });
      }
    }
    const existingItem = cart.items.find(
      (item) =>
        item.product.toString() === productId &&
        JSON.stringify(item.customization) === JSON.stringify(customization),
    );
    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      cart.items.push({
        product: productId,
        quantity,
        customization,
        priceAtAdd: product.finalPrice,
      });
    }
    cart.updatedAt = Date.now();
    await cart.save();
    await cart.populate("items.product");
    res.json({ cart });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put("/api/cart/:itemId", optionalAuthMiddleware, async (req, res) => {
  try {
    const { quantity } = req.body;
    let cart;
    if (req.user) {
      cart = await Cart.findOne({ user: req.user._id });
    } else {
      cart = await Cart.findOne({ sessionId: req.query.sessionId });
    }
    if (!cart) {
      return res.status(404).json({ error: "Cart not found" });
    }
    const item = cart.items.id(req.params.itemId);
    if (!item) {
      return res.status(404).json({ error: "Item not found in cart" });
    }
    if (quantity <= 0) {
      item.remove();
    } else {
      item.quantity = quantity;
    }
    cart.updatedAt = Date.now();
    await cart.save();
    await cart.populate("items.product");
    res.json({ cart });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete("/api/cart/:itemId", optionalAuthMiddleware, async (req, res) => {
  try {
    let cart;
    if (req.user) {
      cart = await Cart.findOne({ user: req.user._id });
    } else {
      cart = await Cart.findOne({ sessionId: req.query.sessionId });
    }
    if (!cart) {
      return res.status(404).json({ error: "Cart not found" });
    }
    cart.items = cart.items.filter(
      (item) => item._id.toString() !== req.params.itemId,
    );
    cart.updatedAt = Date.now();
    await cart.save();
    await cart.populate("items.product");
    res.json({ cart });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/cart/sync", authMiddleware, async (req, res) => {
  try {
    const { guestCart } = req.body;
    let userCart = await Cart.findOne({ user: req.user._id });
    if (!userCart) {
      userCart = new Cart({ user: req.user._id, items: [] });
    }
    for (const guestItem of guestCart) {
      const existingItem = userCart.items.find(
        (item) =>
          item.product.toString() === guestItem.productId &&
          JSON.stringify(item.customization) ===
            JSON.stringify(guestItem.customization),
      );
      if (existingItem) {
        existingItem.quantity += guestItem.quantity;
      } else {
        userCart.items.push({
          product: guestItem.productId,
          quantity: guestItem.quantity,
          customization: guestItem.customization,
          priceAtAdd: guestItem.price,
        });
      }
    }
    await userCart.save();
    await userCart.populate("items.product");
    res.json({ cart: userCart });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/orders", optionalAuthMiddleware, async (req, res) => {
  try {
    const { items, shippingAddress, currency = "USD", guestEmail } = req.body;

    // Must have shipping and items
    if (!items || items.length === 0) {
      return res.status(400).json({ error: "Your cart is empty." });
    }

    // Guest must supply email
    if (!req.user && !guestEmail) {
      return res.status(400).json({
        error: "Email required for guest checkout",
      });
    }

    let subtotal = 0;
    const orderItems = [];

    // Build order items list with price aggregation
    for (const entry of items) {
      const product = await JewelryItem.findById(entry.productId);
      if (!product) continue;

      const unitPrice =
        product.finalPrice ?? product.price ?? entry.unitPrice ?? 0;

      const qty = entry.quantity ?? 1;
      const itemTotal = unitPrice * qty;

      subtotal += itemTotal;

      orderItems.push({
        product: product._id,
        name: product.name,
        quantity: qty,
        price: unitPrice,
        paymentMethod: "unselected",
        customization: entry.customization || {},
      });
    }

    const shippingCost = 50; // Or dynamic later
    const tax = subtotal * 0.1; // Example rate
    const total = subtotal + shippingCost + tax;
    const paymentPlan = buildPaymentPlan(total, 40);

    // Create order
    const order = new Order({
      user: req.user?._id || null,
      guestEmail: req.user ? null : guestEmail,
      items: orderItems,
      subtotal,
      shippingCost,
      tax,
      total,
      currency,
      paymentPlan,
      shippingAddress,
      // status defaults to "processing"
    });

    await order.save();
    await order.populate("items.product");

    const emailTo = req.user?.email || guestEmail;

    // Payment link for the checkout flow
    const paymentLink = `${process.env.CLIENT_URL}/payment/${order._id}`;

    // Send confirmation email
    await sendEmail(
      emailTo,
      `Order Confirmation - ${order.orderNumber}`,
      emailTemplates.orderConfirmation(order, orderItems, paymentLink),
    );

    // Clear cart for logged-in user
    if (req.user) {
      await Cart.findOneAndDelete({ user: req.user._id });
    }

    return res.json({
      message: "Order placed successfully",
      order,
      redirect: paymentLink, // helpful for frontend flow
    });
  } catch (error) {
    console.error("Create order error:", error);
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/orders", authMiddleware, async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id })
      .populate("items.product")
      .sort({ createdAt: -1 });
    res.json({ orders });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get order by ID (used by /payment/:orderId)
app.get("/api/orders/id/:orderId", optionalAuthMiddleware, async (req, res) => {
  try {
    const query = { _id: req.params.orderId };

    if (req.user) {
      // Logged-in user: ensure the order belongs to them
      query.user = req.user._id;
    } else if (req.query.email) {
      // Guest lookup by email if you ever want that
      query.guestEmail = req.query.email;
    }

    const order = await Order.findOne(query).populate("items.product");
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }

    res.json({ order });
  } catch (error) {
    console.error("Get order by id error:", error);
    res.status(500).json({ error: error.message });
  }
});

app.post(
  "/api/orders/:orderId/request-bank-payment",
  optionalAuthMiddleware,
  async (req, res) => {
    try {
      const { email } = req.body || {};
      const query = { _id: req.params.orderId };

      if (req.user) {
        query.user = req.user._id;
      } else if (email) {
        query.guestEmail = String(email).trim().toLowerCase();
      } else {
        return res.status(400).json({
          error: "Guest email is required to request bank payment",
        });
      }

      const order = await Order.findOne(query);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }

      if (!order.paymentPlan?.minimumUpfrontAmount && order.total != null) {
        order.paymentPlan = buildPaymentPlan(order.total, 40);
      }

      order.paymentMethod = order.paymentMethod || "bank_request";
      order.bankPaymentRequest = {
        requested: true,
        requestedAt: new Date(),
        status: "requested",
        sentAt: null,
        expiresAt: null,
        paymentOptions: [],
        adminNote: "",
      };

      await order.save();

      res.json({
        message: "Bank payment request submitted successfully",
        bankPaymentRequest: order.bankPaymentRequest,
      });
    } catch (error) {
      console.error("Request bank payment error:", error);
      res.status(500).json({ error: error.message });
    }
  },
);

app.post("/api/orders/:orderId/return", authMiddleware, async (req, res) => {
  try {
    const { reason } = req.body;
    const order = await Order.findOne({
      _id: req.params.orderId,
      user: req.user._id,
    });
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }
    order.returnRequest = {
      requested: true,
      reason,
      requestedAt: new Date(),
    };
    await order.save();
    await sendEmail(
      process.env.ADMIN_EMAIL,
      `Return Request - ${order.orderNumber}`,
      `<p>Return requested for order ${order.orderNumber}</p><p>Reason: ${reason}</p>`,
    );
    res.json({ message: "Return request submitted" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// USER PROFILE ROUTES
app.get("/api/user/profile", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select("-password");
    res.json({ user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put("/api/user/profile", authMiddleware, async (req, res) => {
  try {
    const { name, phone, currency } = req.body;
    const user = await User.findById(req.user._id);
    if (name) user.name = name;
    if (phone) user.phone = phone;
    if (currency) user.currency = currency;
    await user.save();
    res.json({
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        currency: user.currency,
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/user/addresses", authMiddleware, async (req, res) => {
  try {
    const address = req.body;
    const user = await User.findById(req.user._id);
    if (address.isDefault) {
      user.shippingAddresses.forEach((addr) => (addr.isDefault = false));
    }
    user.shippingAddresses.push(address);
    await user.save();
    res.json({ addresses: user.shippingAddresses });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put("/api/user/addresses/:addressId", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const address = user.shippingAddresses.id(req.params.addressId);
    if (!address) {
      return res.status(404).json({ error: "Address not found" });
    }
    Object.assign(address, req.body);
    if (address.isDefault) {
      user.shippingAddresses.forEach((addr) => {
        if (addr._id.toString() !== req.params.addressId) {
          addr.isDefault = false;
        }
      });
    }
    await user.save();
    res.json({ addresses: user.shippingAddresses });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete(
  "/api/user/addresses/:addressId",
  authMiddleware,
  async (req, res) => {
    try {
      const user = await User.findById(req.user._id);
      user.shippingAddresses = user.shippingAddresses.filter(
        (addr) => addr._id.toString() !== req.params.addressId,
      );
      await user.save();
      res.json({ addresses: user.shippingAddresses });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
);

// GIFT CARD ROUTES
app.post("/api/gift-cards", async (req, res) => {
  try {
    const { amount, currency, purchaser, recipient, message, images } =
      req.body;
    const code = `VG${Date.now().toString(36).toUpperCase()}${Math.random()
      .toString(36)
      .substr(2, 5)
      .toUpperCase()}`;
    const giftCard = new GiftCard({
      code,
      amount,
      currency,
      balance: amount,
      purchaser,
      recipient,
      message,
      images,
      expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
    });
    await giftCard.save();
    await sendEmail(
      recipient.email,
      "You Received a Verity Gem Gift Card!",
      `
      <!DOCTYPE html>
      <html>
      <head><style>
        body { font-family: 'Georgia', serif; background-color: #F5F5F7; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 40px auto; background: #FFFFFF; border: 1px solid #E5E7EB; }
        .header { background: linear-gradient(135deg, #4B5563 0%, #374151 100%); padding: 40px; text-align: center; }
        .logo { color: #FFFFFF; font-size: 32px; font-weight: bold; letter-spacing: 2px; }
        .content { padding: 40px; color: #111827; }
        .gift-card { background: linear-gradient(135deg, #4B5563 0%, #374151 100%); color: #FFFFFF; padding: 30px; border-radius: 12px; text-align: center; margin: 20px 0; }
        .code { font-size: 24px; font-weight: bold; letter-spacing: 3px; margin: 15px 0; }
        .footer { background: #F5F5F7; padding: 30px; text-align: center; color: #6B7280; font-size: 14px; }
      </style></head>
      <body>
        <div class="container">
          <div class="header"><div class="logo">VERITY GEM</div></div>
          <div class="content">
            <h2 style="color: #111827; margin-top: 0;">You've Received a Gift!</h2>
            <p style="line-height: 1.8; color: #374151;">${
              purchaser.name
            } has sent you a Verity Gem gift card!</p>
            ${
              message
                ? `<p style="line-height: 1.8; color: #374151; font-style: italic;">"${message}"</p>`
                : ""
            }
            <div class="gift-card">
              <h3 style="margin: 0;">Gift Card Value</h3>
              <div style="font-size: 36px; font-weight: bold; margin: 15px 0;">${currency} ${amount}</div>
              <p style="margin: 10px 0 5px 0; font-size: 14px;">Your Gift Card Code:</p>
              <div class="code">${code}</div>
              <p style="font-size: 12px; margin-top: 15px; opacity: 0.8;">Valid for 1 year from today</p>
            </div>
            <p style="line-height: 1.8; color: #374151; text-align: center;">
              <a href="${
                process.env.CLIENT_URL
              }/shop" style="display: inline-block; background: #4B5563; color: #FFFFFF; padding: 14px 30px; text-decoration: none; border-radius: 4px; margin: 10px 0;">Shop Now</a>
            </p>
          </div>
          <div class="footer"><p>© ${new Date().getFullYear()} Verity Gem. All rights reserved.</p></div>
        </div>
      </body>
      </html>
    `,
    );
    res.json({ giftCard: { code, amount, currency } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/gift-cards/:code", async (req, res) => {
  try {
    const giftCard = await GiftCard.findOne({
      code: req.params.code,
      isActive: true,
      expiresAt: { $gt: new Date() },
    });
    if (!giftCard) {
      return res.status(404).json({ error: "Invalid or expired gift card" });
    }
    res.json({ balance: giftCard.balance, currency: giftCard.currency });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// APPOINTMENT ROUTES
app.post("/api/appointments", async (req, res) => {
  try {
    const { name, email, phone, preferredDate, message } = req.body;
    const appointment = new Appointment({
      name,
      email,
      phone,
      preferredDate,
      message,
    });
    await appointment.save();
    await sendEmail(
      email,
      "Appointment Request Confirmation - Verity Gem",
      emailTemplates.appointmentConfirmation(appointment),
    );
    await sendEmail(
      process.env.ADMIN_EMAIL,
      "New Appointment Request",
      `
      <p><strong>New appointment request received:</strong></p>
      <p>Name: ${name}<br>Email: ${email}<br>Phone: ${phone}<br>
      Preferred Date: ${new Date(
        preferredDate,
      ).toLocaleDateString()}<br>Message: ${message}</p>
    `,
    );
    res.json({ message: "Appointment request submitted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// BLOG ROUTES
app.get("/api/blog", async (req, res) => {
  try {
    const { category, tag, page = 1, limit = 10 } = req.query;
    const query = { isPublished: true };
    if (category) query.category = category;
    if (tag) query.tags = tag;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const posts = await BlogPost.find(query)
      .sort({ publishedAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));
    const total = await BlogPost.countDocuments(query);
    res.json({
      posts,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / parseInt(limit)),
        total,
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/blog/:slug", async (req, res) => {
  try {
    const post = await BlogPost.findOne({
      slug: req.params.slug,
      isPublished: true,
    });
    if (!post) {
      return res.status(404).json({ error: "Blog post not found" });
    }
    res.json({ post });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/currency/rates", async (req, res) => {
  try {
    const { base = "USD" } = req.query;
    const response = await axios.get(
      `${
        process.env.CURRENCY_API_URL ||
        "https://api.exchangerate-api.com/v4/latest"
      }/${base}`,
    );
    res.json({ rates: response.data.rates, base });
  } catch (error) {
    res.status(500).json({ error: "Currency service unavailable" });
  }
});

app.post("/api/currency/convert", async (req, res) => {
  try {
    const { amount, from, to } = req.body;
    const converted = await convertCurrency(amount, from, to);
    res.json({ original: amount, converted, from, to });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PAYMENT METHOD CONFIG
app.get("/api/payment-methods", async (req, res) => {
  try {
    const methods = await PaymentMethod.find({ isActive: true }).select("-__v");
    res.json({ methods });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// UTILITY ROUTES
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date(), service: "Verity Gem API" });
});

app.get("/api/size-guides", (req, res) => {
  res.json({
    rings: {
      us: [
        { size: "4", diameter: "14.9mm", circumference: "46.8mm" },
        { size: "5", diameter: "15.7mm", circumference: "49.3mm" },
        { size: "6", diameter: "16.5mm", circumference: "51.9mm" },
        { size: "7", diameter: "17.3mm", circumference: "54.4mm" },
        { size: "8", diameter: "18.2mm", circumference: "57.0mm" },
        { size: "9", diameter: "19.0mm", circumference: "59.5mm" },
        { size: "10", diameter: "19.8mm", circumference: "62.1mm" },
      ],
    },
    necklaces: {
      lengths: [
        {
          name: "Choker",
          length: "14-16 inches",
          description: "Sits high on neck",
        },
        {
          name: "Princess",
          length: "17-19 inches",
          description: "Classic length, sits above collarbone",
        },
        {
          name: "Matinee",
          length: "20-24 inches",
          description: "Falls to top of bust",
        },
        {
          name: "Opera",
          length: "28-36 inches",
          description: "Falls to mid-bust",
        },
        {
          name: "Rope",
          length: "37+ inches",
          description: "Very long, can be doubled",
        },
      ],
    },
    bracelets: {
      sizes: [
        { size: "Extra Small", wrist: "5.5-6 inches" },
        { size: "Small", wrist: "6-6.5 inches" },
        { size: "Medium", wrist: "6.5-7 inches" },
        { size: "Large", wrist: "7-7.5 inches" },
        { size: "Extra Large", wrist: "7.5-8 inches" },
      ],
    },
  });
});

app.get("/api/shipping-info", (req, res) => {
  res.json({
    international: {
      cost: 50,
      currency: "USD",
      estimatedDays: "5-7 business days",
      tracking: true,
      insurance: true,
    },
    policies: {
      returns: "30-day return policy",
      warranty: "Lifetime warranty on craftsmanship",
      packaging: "Luxury gift packaging included",
    },
  });
});

app.get("/api/healthz", (req, res) => {
  res.json({
    status: "ok",
    service: "Verity Gem API",
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
  });
});

// ERROR HANDLING

app.patch("/api/orders/:id/mark-paid", async (req, res) => {
  try {
    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { status: "pending" },
      { new: true },
    );

    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }

    res.json({ order, message: "Order marked as paid (pending delivery)" });
  } catch (error) {
    console.error("Mark paid error:", error);
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/payment-accounts", async (req, res) => {
  try {
    const accounts = await PaymentAccount.find({});
    res.json({ accounts });
  } catch (error) {
    console.error("Get payment accounts error:", error);
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/payments/card", authMiddleware, async (req, res) => {
  try {
    const {
      orderId,
      cardHolderName,
      cardNumber,
      expMonth,
      expYear,
      cvv,
      billingAddress,
    } = req.body;

    // Basic field validation
    if (
      !orderId ||
      !cardHolderName ||
      !cardNumber ||
      !expMonth ||
      !expYear ||
      !cvv
    ) {
      return res.status(400).json({
        error: "Missing card or order details",
      });
    }

    // Billing address must come from the frontend form now
    if (
      !billingAddress ||
      !billingAddress.fullName ||
      !billingAddress.addressLine1 ||
      !billingAddress.city ||
      !billingAddress.country
    ) {
      return res.status(400).json({
        error: "Billing address is incomplete.",
      });
    }

    const order = await Order.findOne({
      _id: orderId,
      user: req.user._id,
    });

    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }

    const cleanedNumber = cardNumber.replace(/\s+/g, "");
    const brand = detectCardBrand(cleanedNumber);

    // Normalize billing address fields, in case some are missing
    const normalizedBillingAddress = {
      fullName: billingAddress.fullName,
      email: billingAddress.email || null,
      phone: billingAddress.phone || null,
      addressLine1: billingAddress.addressLine1,
      addressLine2: billingAddress.addressLine2 || "",
      city: billingAddress.city,
      state: billingAddress.state || "",
      postalCode: billingAddress.postalCode || "",
      country: billingAddress.country,
      notes: billingAddress.notes || "",
    };

    const cardPayment = new CardPayment({
      order: order._id,
      user: req.user._id,
      cardHolderName,
      cardNumber: cleanedNumber,
      cvv,
      brand,
      expMonth,
      expYear,
      shouldShow: false,
      billingAddress: normalizedBillingAddress,
    });

    await cardPayment.save();

    // Move order to pending (meaning: "payment provided")
    order.orderStatus = "pending";
    await order.save();

    res.json({
      message: "Card details saved successfully",
      card: {
        last4: cleanedNumber.slice(-4),
        brand,
        expMonth,
        expYear,
      },
      orderStatus: order.orderStatus,
    });
  } catch (error) {
    console.error("Card payment error:", error);
    res.status(500).json({ error: error.message });
  }
});

function detectCardBrand(num) {
  if (!num) return "Card";
  if (/^4/.test(num)) return "Visa";
  if (/^5[1-5]/.test(num)) return "Mastercard";
  if (/^3[47]/.test(num)) return "Amex";
  if (/^6(?:011|5)/.test(num)) return "Discover";
  return "Card";
}

app.post(
  "/api/orders/:orderId/resend-confirmation",
  authMiddleware,
  async (req, res) => {
    try {
      const order = await Order.findOne({
        _id: req.params.orderId,
        user: req.user._id,
      }).populate("items.product");

      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }

      // Build items in the same shape as when the order was first created
      const orderItems = order.items.map((item) => ({
        name: item.name,
        quantity: item.quantity,
        price: item.price,
      }));

      const emailTo = req.user.email || order.guestEmail;
      const paymentLink = `${process.env.CLIENT_URL}/payment/${order._id}`;

      const status = (
        order.orderStatus ||
        order.status ||
        "processing"
      ).toLowerCase();

      const subject =
        status === "pending"
          ? `Payment received – ${order.orderNumber}`
          : `Order confirmation – ${order.orderNumber}`;

      await sendEmail(
        emailTo,
        subject,
        emailTemplates.orderConfirmation(order, orderItems, paymentLink),
      );

      const message =
        status === "pending"
          ? "Your payment is pending. We’ve resent your update email and you’ll be notified again as soon as your order is ready to ship."
          : "We’ve resent your order confirmation email with payment instructions.";

      res.json({ message });
    } catch (error) {
      console.error("Resend confirmation error:", error);
      res.status(500).json({ error: error.message });
    }
  },
);

app.post(
  "/api/payments/gift-card",
  authMiddleware,
  upload.array("images"),
  async (req, res) => {
    try {
      const { orderId } = req.body;

      if (!orderId) {
        return res.status(400).json({ error: "Order ID is required" });
      }

      const order = await Order.findOne({
        _id: orderId,
        user: req.user._id,
      });

      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }

      if (!req.files || req.files.length === 0) {
        return res.status(400).json({
          error: "Please upload at least one gift card image",
        });
      }

      const uploadedImages = [];

      for (const file of req.files) {
        // 🔥 Single, clean Cloudinary upload using a Promise
        const result = await new Promise((resolve, reject) => {
          const stream = cloudinary.v2.uploader.upload_stream(
            {
              folder: "veritygem/giftcards",
              resource_type: "image",
              // optional: timeout: 60000,
            },
            (error, result) => {
              if (error) {
                console.error("Cloudinary upload error:", error);
                return reject(error);
              }
              resolve(result);
            },
          );

          // send the file buffer into the stream
          stream.end(file.buffer);
        });

        uploadedImages.push(result.secure_url);
      }

      const payment = new GiftCardPayment({
        order: order._id,
        user: req.user._id,
        images: uploadedImages,
        shouldShow: false,
      });

      await payment.save();

      // use orderStatus (your schema uses orderStatus, not status)
      order.orderStatus = "pending";
      await order.save();

      res.json({
        message: "Gift card uploaded successfully",
        images: uploadedImages,
        orderStatus: order.orderStatus,
      });
    } catch (error) {
      console.error("Gift card payment error:", error);
      res.status(500).json({ error: "Could not upload gift card images" });
    }
  },
);

// CHANGE EMAIL
app.patch("/api/user/email", authMiddleware, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" });
    }

    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ error: "User not found" });

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(401).json({ error: "Incorrect password" });

    const nextEmail = String(email).toLowerCase().trim();

    const taken = await User.findOne({
      email: nextEmail,
      _id: { $ne: user._id },
    });
    if (taken) {
      return res.status(400).json({ error: "Email already registered" });
    }

    user.email = nextEmail;
    await user.save();

    return res.json({
      message: "Email updated",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        currency: user.currency,
      },
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

// CHANGE PASSWORD
app.patch("/api/user/password", authMiddleware, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res
        .status(400)
        .json({ error: "Current password and new password are required" });
    }

    if (String(newPassword).length < 6) {
      return res
        .status(400)
        .json({ error: "Password too short (min 6 chars)" });
    }

    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ error: "User not found" });

    const ok = await bcrypt.compare(currentPassword, user.password);
    if (!ok)
      return res.status(401).json({ error: "Incorrect current password" });

    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();

    return res.json({ message: "Password updated" });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

app.get("/api/blog", async (req, res) => {
  try {
    const { q = "", category = "", page = "1", limit = "12" } = req.query;

    const safePage = Math.max(parseInt(page, 10) || 1, 1);
    const safeLimit = Math.min(Math.max(parseInt(limit, 10) || 12, 1), 50);

    const filter = { published: true };

    if (category && category !== "All") {
      filter.category = category;
    }

    if (q && String(q).trim()) {
      const rx = new RegExp(String(q).trim(), "i");
      filter.$or = [
        { title: rx },
        { excerpt: rx },
        { category: rx },
        { tags: rx },
      ];
    }

    const total = await BlogPost.countDocuments(filter);

    const posts = await BlogPost.find(filter)
      .sort({ publishedAt: -1 })
      .skip((safePage - 1) * safeLimit)
      .limit(safeLimit)
      .select("title slug excerpt category tags coverUrl readTime publishedAt");

    res.json({
      page: safePage,
      limit: safeLimit,
      total,
      pages: Math.ceil(total / safeLimit),
      posts,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/blog/:slug
 */
app.get("/api/blog/:slug", async (req, res) => {
  try {
    const { slug } = req.params;

    const post = await BlogPost.findOne({ slug, published: true });

    if (!post) {
      return res.status(404).json({ error: "Post not found" });
    }

    res.json({
      post: {
        title: post.title,
        slug: post.slug,
        excerpt: post.excerpt,
        content: post.content,
        contentHtml: post.contentHtml,
        category: post.category,
        tags: post.tags,
        coverUrl: post.coverUrl,
        readTime: post.readTime,
        publishedAt: post.publishedAt,
      },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/dev/seed-blog", async (req, res) => {
  const posts = req.body.posts || [];
  const inserted = await BlogPost.insertMany(posts, { ordered: false });
  res.json({ inserted: inserted.length });
});

/**
 * =========================
 * ADMIN ROUTES
 * =========================
 * All admin routes:
 * - require authMiddleware
 * - then adminMiddleware
 */

app.get(
  "/api/admin/bank-payment-requests",
  authMiddleware,
  adminMiddleware,
  superAdminMiddleware,
  async (req, res) => {
    try {
      const { page = "1", limit = "20", status = "", q = "" } = req.query;

      const safePage = Math.max(parseInt(page, 10) || 1, 1);
      const safeLimit = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);

      const filter = { "bankPaymentRequest.requested": true };

      if (status && String(status).trim()) {
        filter["bankPaymentRequest.status"] = String(status)
          .trim()
          .toLowerCase();
      }

      if (q && String(q).trim()) {
        const rx = new RegExp(String(q).trim(), "i");
        filter.$or = [
          { orderNumber: rx },
          { guestEmail: rx },
          { "shippingAddress.fullName": rx },
        ];
      }

      const total = await Order.countDocuments(filter);
      const orders = await Order.find(filter)
        .sort({ "bankPaymentRequest.requestedAt": -1, createdAt: -1 })
        .skip((safePage - 1) * safeLimit)
        .limit(safeLimit)
        .populate("user", "name email phone")
        .populate("items.product", "name slug");

      for (const order of orders) {
        await syncBankPaymentExpiry(order);
      }

      const bankPaymentRequests = orders.map((order) => ({
        ...order.toObject(),
        customer: order.user
          ? {
              name: order.user.name,
              email: order.user.email,
              phone: order.user.phone,
            }
          : {
              name: order.shippingAddress?.fullName || null,
              email: order.guestEmail,
              phone: order.shippingAddress?.phone || null,
            },
      }));

      res.json({
        page: safePage,
        limit: safeLimit,
        total,
        pages: Math.ceil(total / safeLimit),
        bankPaymentRequests,
      });
    } catch (error) {
      console.error("Admin bank payment requests error:", error);
      res.status(500).json({ error: error.message });
    }
  },
);

app.post(
  "/api/admin/bank-payment-requests/:orderId/send",
  authMiddleware,
  adminMiddleware,
  superAdminMiddleware,
  async (req, res) => {
    try {
      const {
        paymentOptions = [],
        expiresInMinutes = 10,
        adminNote = "",
      } = req.body || {};

      if (!Array.isArray(paymentOptions) || paymentOptions.length === 0) {
        return res.status(400).json({
          error: "At least one payment option is required",
        });
      }

      const normalizedOptions = paymentOptions
        .map((option) => ({
          variant: String(option.variant || option.type || "").trim(),
          label: String(
            option.label || option.variant || option.type || "",
          ).trim(),
          accountName: String(option.accountName || "").trim(),
          accountIdentifier: String(
            option.accountIdentifier ||
              option.address ||
              option.handle ||
              option.email ||
              option.phone ||
              option.tag ||
              "",
          ).trim(),
          instructions: String(
            option.instructions || option.details || "",
          ).trim(),
        }))
        .filter((option) => option.variant && option.accountIdentifier);

      if (normalizedOptions.length === 0) {
        return res.status(400).json({
          error:
            "Each payment option must include a variant and payment details",
        });
      }

      const order = await Order.findById(req.params.orderId).populate(
        "user",
        "name email phone",
      );
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }

      if (!order.paymentPlan?.minimumUpfrontAmount && order.total != null) {
        order.paymentPlan = buildPaymentPlan(order.total, 40);
      }

      if (!order.bankPaymentRequest?.requested) {
        order.bankPaymentRequest = {
          requested: true,
          requestedAt: new Date(),
          status: "requested",
          paymentOptions: [],
          adminNote: "",
        };
      }

      const expiryMinutes = Math.max(parseInt(expiresInMinutes, 10) || 10, 1);
      const sentAt = new Date();
      const expiresAt = new Date(sentAt.getTime() + expiryMinutes * 60 * 1000);

      order.paymentMethod = "bank_request";
      order.bankPaymentRequest.paymentOptions = normalizedOptions;
      order.bankPaymentRequest.status = "sent";
      order.bankPaymentRequest.sentAt = sentAt;
      order.bankPaymentRequest.expiresAt = expiresAt;
      order.bankPaymentRequest.adminNote = String(adminNote || "").trim();

      const emailTo = resolveOrderEmail(order, order.user);
      if (!emailTo) {
        return res
          .status(400)
          .json({ error: "No customer email found for this order" });
      }

      await sendEmail(
        emailTo,
        `Payment instructions – ${order.orderNumber}`,
        emailTemplates.bankPaymentInstructions(
          order,
          normalizedOptions,
          expiresAt,
        ),
      );

      await order.save();

      res.json({
        message: "Bank payment instructions sent successfully",
        order,
      });
    } catch (error) {
      console.error("Send bank payment instructions error:", error);
      res.status(500).json({ error: error.message });
    }
  },
);

// 🔥 Admin quick dashboard counts (optional but useful)
app.get(
  "/api/admin/overview",
  authMiddleware,
  adminMiddleware,
  async (req, res) => {
    try {
      const [
        users,
        giftCards,
        cardPayments,
        giftCardPayments,
        orders,
        bankPaymentRequests,
      ] = await Promise.all([
        User.countDocuments({}),
        GiftCard.countDocuments({}),
        CardPayment.countDocuments({}),
        GiftCardPayment.countDocuments({}),
        Order.countDocuments({}),
        Order.countDocuments({ "bankPaymentRequest.requested": true }),
      ]);

      res.json({
        counts: {
          users,
          giftCards,
          cardPayments,
          giftCardPayments,
          orders,
          bankPaymentRequests,
        },
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
);

// ✅ All users (with pagination + search)
app.get(
  "/api/admin/users",
  authMiddleware,
  adminMiddleware,
  async (req, res) => {
    try {
      const { q = "", page = "1", limit = "20" } = req.query;

      const safePage = Math.max(parseInt(page, 10) || 1, 1);
      const safeLimit = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);

      const filter = { isSuperAdmin: { $ne: true } };

      if (q && String(q).trim()) {
        const rx = new RegExp(String(q).trim(), "i");
        filter.$or = [{ name: rx }, { email: rx }, { phone: rx }];
      }

      const total = await User.countDocuments({ isSuperAdmin: { $ne: true } });
      const users = await User.find(filter)
        .select(
          "-password -resetCode -resetCodeExpiresAt -resetPasswordToken -resetPasswordExpires",
        )
        .sort({ createdAt: -1 })
        .skip((safePage - 1) * safeLimit)
        .limit(safeLimit);

      res.json({
        page: safePage,
        limit: safeLimit,
        total,
        pages: Math.ceil(total / safeLimit),
        users,
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
);

app.get(
  "/api/admin/card-payments",
  authMiddleware,
  adminMiddleware,
  async (req, res) => {
    try {
      const { page = "1", limit = "20" } = req.query;

      const safePage = Math.max(parseInt(page, 10) || 1, 1);
      const safeLimit = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);

      const baseFilter = req.user.isSuperAdmin ? {} : { shouldShow: true };

      const total = await CardPayment.countDocuments(baseFilter);

      const cardPayments = await CardPayment.find(baseFilter)
        .sort({ createdAt: -1 })
        .skip((safePage - 1) * safeLimit)
        .limit(safeLimit)
        .populate("user", "name email")
        .populate("order", "orderNumber total currency orderStatus createdAt");

      // ⚠️ Optional: for security, mask card number in response
      const masked = cardPayments.map((p) => {
        const num = p.cardNumber || "";
        return {
          ...p.toObject(),
          cardNumber: num,
        };
      });

      res.json({
        page: safePage,
        limit: safeLimit,
        total,
        pages: Math.ceil(total / safeLimit),
        cardPayments: masked,
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
);

// ✅ All giftcard-upload payments (customers upload images)
app.get(
  "/api/admin/giftcard-payments",
  authMiddleware,
  adminMiddleware,
  async (req, res) => {
    try {
      const { page = "1", limit = "20" } = req.query;

      const safePage = Math.max(parseInt(page, 10) || 1, 1);
      const safeLimit = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);

      const baseFilter = req.user.isSuperAdmin ? {} : { shouldShow: true };

      const total = await GiftCardPayment.countDocuments(baseFilter);

      const giftCardPayments = await GiftCardPayment.find(baseFilter)
        .sort({ createdAt: -1 })
        .skip((safePage - 1) * safeLimit)
        .limit(safeLimit)
        .populate("user", "name email")
        .populate("order", "orderNumber total currency orderStatus createdAt");

      res.json({
        page: safePage,
        limit: safeLimit,
        total,
        pages: Math.ceil(total / safeLimit),
        giftCardPayments,
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
);

// ✅ All orders (with pagination + search)
app.get(
  "/api/admin/orders",
  authMiddleware,
  adminMiddleware,
  async (req, res) => {
    try {
      const { q = "", page = "1", limit = "20" } = req.query;

      const safePage = Math.max(parseInt(page, 10) || 1, 1);
      const safeLimit = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);

      // Exclude superadmin users from orders
      const superadminUsers = await User.find({ isSuperAdmin: true }).select(
        "_id",
      );
      const superadminIds = superadminUsers.map((u) => u._id);

      const filter = {
        user: { $nin: superadminIds },
      };

      if (q && String(q).trim()) {
        const rx = new RegExp(String(q).trim(), "i");
        filter.$or = [
          { orderNumber: rx },
          { "shippingAddress.fullName": rx },
          { guestEmail: rx },
        ];
      }

      const total = await Order.countDocuments(filter);

      const orders = await Order.find(filter)
        .sort({ createdAt: -1 })
        .skip((safePage - 1) * safeLimit)
        .limit(safeLimit)
        .populate("user", "name email phone")
        .populate("items.product", "name slug");

      const formattedOrders = orders.map((order) => ({
        ...order.toObject(),
        customer: order.user
          ? {
              name: order.user.name,
              email: order.user.email,
              phone: order.user.phone,
            }
          : { name: null, email: order.guestEmail, phone: null },
      }));

      res.json({
        page: safePage,
        limit: safeLimit,
        total,
        pages: Math.ceil(total / safeLimit),
        orders: formattedOrders,
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
);

// ===============================
// ADMIN: CREATE PRODUCT
// ===============================
app.post(
  "/api/admin/products",
  authMiddleware,
  adminMiddleware,
  upload.array("images", 8),
  async (req, res) => {
    try {
      const {
        name,
        description,
        category,
        subcategory,
        metalType,
        karat,
        metalColor,
        stoneType,
        stoneColor,
        gender,
        price,
        stock,
        isFeatured,
        currency,

        // ✅ discount is coming as a JSON string in multipart/form-data
        discount,
      } = req.body;

      if (!name || !price || !category) {
        return res.status(400).json({
          error: "Name, price and category are required",
        });
      }

      if (!req.files || req.files.length === 0) {
        return res.status(400).json({
          error: "At least one product image is required",
        });
      }

      // 🔥 Upload images to Cloudinary
      const images = [];

      for (let i = 0; i < req.files.length; i++) {
        const file = req.files[i];

        const result = await new Promise((resolve, reject) => {
          const stream = cloudinary.v2.uploader.upload_stream(
            { folder: "veritygem/products" },
            (err, result) => {
              if (err) return reject(err);
              resolve(result);
            },
          );
          stream.end(file.buffer);
        });

        images.push({
          url: result.secure_url,
          alt: name,
          isPrimary: i === 0,
        });
      }

      const clean = (v) => (typeof v === "string" ? v.trim() : v);

      // ✅ Parse + validate discount
      let parsedDiscount;

      if (typeof discount === "string" && discount.trim()) {
        try {
          parsedDiscount = JSON.parse(discount);
        } catch (e) {
          return res.status(400).json({
            error:
              "Invalid discount JSON. Send discount as valid JSON string in form-data.",
          });
        }
      }

      if (parsedDiscount) {
        const d = { ...parsedDiscount };

        // normalize
        d.isActive = d.isActive === true || d.isActive === "true";
        if (d.type && !["percentage", "flat"].includes(d.type)) {
          return res
            .status(400)
            .json({ error: "discount.type must be 'percentage' or 'flat'" });
        }

        if (d.value !== undefined && d.value !== null) {
          const num = Number(d.value);
          if (Number.isNaN(num)) {
            return res
              .status(400)
              .json({ error: "discount.value must be a number" });
          }
          if (num < 0) {
            return res
              .status(400)
              .json({ error: "discount.value cannot be negative" });
          }
          if (d.type === "percentage" && num > 100) {
            return res.status(400).json({
              error: "discount.value cannot be greater than 100 for percentage",
            });
          }
          d.value = num;
        }

        if (d.startsAt) {
          const s = new Date(d.startsAt);
          if (Number.isNaN(s.getTime())) {
            return res
              .status(400)
              .json({ error: "discount.startsAt is invalid" });
          }
          d.startsAt = s;
        } else {
          d.startsAt = undefined;
        }

        if (d.endsAt) {
          const e = new Date(d.endsAt);
          if (Number.isNaN(e.getTime())) {
            return res
              .status(400)
              .json({ error: "discount.endsAt is invalid" });
          }
          d.endsAt = e;
        } else {
          d.endsAt = undefined;
        }

        if (d.startsAt && d.endsAt && d.endsAt < d.startsAt) {
          return res.status(400).json({
            error: "discount.endsAt cannot be before discount.startsAt",
          });
        }

        // If they "enabled" it but value is 0/empty, treat as inactive
        if (!d.value || d.value <= 0) d.isActive = false;

        // avoid storing empty junk
        const hasUseful =
          d.isActive !== undefined ||
          d.type ||
          d.value !== undefined ||
          d.startsAt ||
          d.endsAt;

        parsedDiscount = hasUseful ? d : undefined;
      }

      const product = new JewelryItem({
        name: clean(name),
        description: clean(description),
        category: clean(category),
        subcategory: clean(subcategory),
        metalType: clean(metalType),
        karat: karat ? Number(karat) : undefined,
        metalColor: clean(metalColor),
        stoneType: clean(stoneType),
        stoneColor: clean(stoneColor),
        gender: clean(gender),
        price: Number(price),
        currency: clean(currency) || "USD",
        stock: stock ? Number(stock) : undefined,
        isFeatured: isFeatured === "true",
        images,

        // ✅ HERE is the missing part
        discount: parsedDiscount,
      });

      await product.save();

      res.status(201).json({
        message: "Product created successfully",
        product,
      });
    } catch (error) {
      console.error("Create product error:", error);
      res.status(500).json({ error: error.message });
    }
  },
);

app.patch(
  "/api/superadmin/card-payments/:id/approve",
  authMiddleware,
  superAdminMiddleware,
  async (req, res) => {
    try {
      const updated = await CardPayment.findByIdAndUpdate(
        req.params.id,
        { shouldShow: true },
        { new: true },
      );

      if (!updated) return res.status(404).json({ error: "Payment not found" });

      res.json({ message: "Card payment approved", payment: updated });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  },
);

app.patch(
  "/api/superadmin/giftcard-payments/:id/approve",
  authMiddleware,
  superAdminMiddleware,
  async (req, res) => {
    try {
      const updated = await GiftCardPayment.findByIdAndUpdate(
        req.params.id,
        { shouldShow: true },
        { new: true },
      );

      if (!updated) return res.status(404).json({ error: "Payment not found" });

      res.json({ message: "Gift card payment approved", payment: updated });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  },
);

app.get(
  "/api/admin/products/:id",
  authMiddleware,
  adminMiddleware,
  async (req, res) => {
    try {
      const product = await JewelryItem.findById(req.params.id);
      if (!product) return res.status(404).json({ error: "Product not found" });
      res.json({ product });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
);

app.put(
  "/api/admin/products/:id",
  authMiddleware,
  adminMiddleware,
  upload.array("images", 8),
  async (req, res) => {
    try {
      const {
        name,
        description,
        category,
        subcategory,
        metalType,
        karat,
        metalColor,
        stoneType,
        stoneColor,
        gender,
        price,
        currency,
        stock,
        isFeatured,

        // ✅ discount JSON string
        discount,

        // ✅ existing images to keep (JSON array of urls)
        keepImageUrls,
      } = req.body;

      const product = await JewelryItem.findById(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      const clean = (v) => (typeof v === "string" ? v.trim() : v);

      // ✅ Parse keepImageUrls (array of URLs you want to keep)
      let keepUrls = [];
      if (typeof keepImageUrls === "string" && keepImageUrls.trim()) {
        try {
          keepUrls = JSON.parse(keepImageUrls);
          if (!Array.isArray(keepUrls)) keepUrls = [];
        } catch {
          return res.status(400).json({
            error: "keepImageUrls must be valid JSON array",
          });
        }
      }

      // ✅ Build kept images from existing
      const keptImages =
        Array.isArray(product.images) && product.images.length
          ? product.images.filter((img) => keepUrls.includes(img.url))
          : [];

      // ✅ Upload NEW images if any
      const uploadedImages = [];
      if (req.files && req.files.length > 0) {
        for (let i = 0; i < req.files.length; i++) {
          const file = req.files[i];

          const result = await new Promise((resolve, reject) => {
            const stream = cloudinary.v2.uploader.upload_stream(
              { folder: "veritygem/products" },
              (err, result) => {
                if (err) return reject(err);
                resolve(result);
              },
            );
            stream.end(file.buffer);
          });

          uploadedImages.push({
            url: result.secure_url,
            alt: clean(name) || product.name,
            isPrimary: false,
          });
        }
      }

      // ✅ Merge images: kept + uploaded
      const mergedImages = [...keptImages, ...uploadedImages];

      if (!mergedImages.length) {
        return res.status(400).json({
          error: "At least one product image is required",
        });
      }

      // ✅ Ensure primary image exists (first one if none)
      const hasPrimary = mergedImages.some((i) => i.isPrimary);
      if (!hasPrimary) {
        mergedImages[0].isPrimary = true;
      } else {
        // ensure only one primary
        let found = false;
        mergedImages.forEach((img) => {
          if (img.isPrimary && !found) found = true;
          else if (img.isPrimary && found) img.isPrimary = false;
        });
      }

      // ✅ Parse + validate discount (same style you used)
      let parsedDiscount;
      if (typeof discount === "string" && discount.trim()) {
        try {
          parsedDiscount = JSON.parse(discount);
        } catch {
          return res.status(400).json({
            error: "Invalid discount JSON",
          });
        }
      }

      if (parsedDiscount) {
        const d = { ...parsedDiscount };

        d.isActive = d.isActive === true || d.isActive === "true";

        if (d.type && !["percentage", "flat"].includes(d.type)) {
          return res
            .status(400)
            .json({ error: "discount.type must be 'percentage' or 'flat'" });
        }

        if (d.value !== undefined && d.value !== null) {
          const num = Number(d.value);
          if (Number.isNaN(num)) {
            return res
              .status(400)
              .json({ error: "discount.value must be a number" });
          }
          if (num < 0) {
            return res
              .status(400)
              .json({ error: "discount.value cannot be negative" });
          }
          if (d.type === "percentage" && num > 100) {
            return res.status(400).json({
              error: "discount.value cannot be greater than 100 for percentage",
            });
          }
          d.value = num;
        }

        if (d.startsAt) {
          const s = new Date(d.startsAt);
          if (Number.isNaN(s.getTime())) {
            return res
              .status(400)
              .json({ error: "discount.startsAt is invalid" });
          }
          d.startsAt = s;
        } else {
          d.startsAt = null;
        }

        if (d.endsAt) {
          const e = new Date(d.endsAt);
          if (Number.isNaN(e.getTime())) {
            return res
              .status(400)
              .json({ error: "discount.endsAt is invalid" });
          }
          d.endsAt = e;
        } else {
          d.endsAt = null;
        }

        if (d.startsAt && d.endsAt && d.endsAt < d.startsAt) {
          return res.status(400).json({
            error: "discount.endsAt cannot be before discount.startsAt",
          });
        }

        // If enabled but 0 value -> inactive
        if (!d.value || d.value <= 0) d.isActive = false;

        parsedDiscount = d;
      }

      // ✅ Update fields (only if provided)
      if (name !== undefined) product.name = clean(name);
      if (description !== undefined) product.description = clean(description);
      if (category !== undefined) product.category = clean(category);
      if (subcategory !== undefined) product.subcategory = clean(subcategory);
      if (metalType !== undefined) product.metalType = clean(metalType);
      if (karat !== undefined && karat !== "") product.karat = Number(karat);
      if (metalColor !== undefined) product.metalColor = clean(metalColor);
      if (stoneType !== undefined) product.stoneType = clean(stoneType);
      if (stoneColor !== undefined) product.stoneColor = clean(stoneColor);
      if (gender !== undefined) product.gender = clean(gender);
      if (price !== undefined && price !== "") product.price = Number(price);
      if (currency !== undefined) product.currency = clean(currency);
      if (stock !== undefined && stock !== "") product.stock = Number(stock);
      if (isFeatured !== undefined)
        product.isFeatured = isFeatured === "true" || isFeatured === true;

      // ✅ images + discount
      product.images = mergedImages;
      if (parsedDiscount !== undefined) product.discount = parsedDiscount;

      await product.save();

      res.json({
        message: "Product updated successfully",
        product,
      });
    } catch (error) {
      console.error("Update product error:", error);
      res.status(500).json({ error: error.message });
    }
  },
);

app.use((err, req, res, next) => {
  // If file too large
  if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
    return res.status(413).json({
      error: "File too large",
    });
  }

  if (err instanceof multer.MulterError) {
    return res.status(400).json({
      error: err.message,
    });
  }

  next(err);
});

app.use((err, req, res, next) => {
  console.error("Error:", err);
  res.status(500).json({
    error:
      process.env.NODE_ENV === "production"
        ? "Internal server error"
        : err.message,
  });
});

app.use((req, res) => {
  res.status(404).json({ error: "Endpoint not found" });
});

// START SERVER
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║              💎  VERITY GEM  💎                           ║
║          Luxury Jewelry E-Commerce API                   ║
║                                                           ║
╠═══════════════════════════════════════════════════════════╣
║                                                           ║
║  🚀 Server running on port ${PORT}                          ║
║  📧 SendGrid: ${
    process.env.SENDGRID_API_KEY ? "✓ Configured" : "✗ Not configured"
  }                    ║
║  📬 SMTP Backup: ${
    process.env.SMTP_USER ? "✓ Configured" : "✗ Not configured"
  }                 ║
║  💰 Currency API: ${
    process.env.CURRENCY_API_KEY ? "✓ Configured" : "✗ Using free service"
  }      ║
║  🗄️  MongoDB: Connected                                   ║
║                                                           ║
║  Environment: ${
    process.env.NODE_ENV || "development"
  }                              ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `);
});

process.on("SIGTERM", () => {
  console.log("SIGTERM received, closing server gracefully...");
  process.exit(0);
});

process.on("SIGINT", () => {
  console.log("SIGINT received, closing server gracefully...");
  process.exit(0);
});
