import { useMemo, useState } from "react";
import api from "../../api/axios";

function money(amount, currency = "USD") {
  if (amount == null || amount === "") return "";
  try {
    return new Intl.NumberFormat(undefined, {
      style: "currency",
      currency,
      maximumFractionDigits: 0,
    }).format(Number(amount));
  } catch {
    return `${currency} ${amount}`;
  }
}

function toISODateTimeLocalValue(d = new Date()) {
  // yyyy-MM-ddTHH:mm (for input type="datetime-local")
  const pad = (x) => String(x).padStart(2, "0");
  const yyyy = d.getFullYear();
  const mm = pad(d.getMonth() + 1);
  const dd = pad(d.getDate());
  const hh = pad(d.getHours());
  const min = pad(d.getMinutes());
  return `${yyyy}-${mm}-${dd}T${hh}:${min}`;
}

function computeOldPriceFromDiscount(currentPrice, discount) {
  const p = Number(currentPrice);
  if (!p || p <= 0) return { hasDiscount: false, oldPrice: null, label: "" };

  if (!discount?.isActive)
    return { hasDiscount: false, oldPrice: null, label: "" };

  const v = Number(discount?.value);
  if (!v || v <= 0) return { hasDiscount: false, oldPrice: null, label: "" };

  // if there's a schedule, and it's out of range, don't preview as active
  const now = new Date();
  if (discount.startsAt && new Date(discount.startsAt) > now) {
    return { hasDiscount: false, oldPrice: null, label: "" };
  }
  if (discount.endsAt && new Date(discount.endsAt) < now) {
    return { hasDiscount: false, oldPrice: null, label: "" };
  }

  if (discount.type === "flat") {
    const oldPrice = p + v;
    return {
      hasDiscount: true,
      oldPrice,
      label: `-${money(v, discount.currency || "USD")}`,
    };
  }

  if (discount.type === "percentage") {
    if (v >= 100) return { hasDiscount: false, oldPrice: null, label: "" };
    const oldPrice = p / (1 - v / 100);
    return { hasDiscount: true, oldPrice, label: `-${Math.round(v)}%` };
  }

  return { hasDiscount: false, oldPrice: null, label: "" };
}

const PricePreview = ({ price, currency, discount }) => {
  const { hasDiscount, oldPrice, label } = computeOldPriceFromDiscount(
    price,
    discount,
  );

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <span className="text-sm text-slate-600">Preview:</span>

      {!hasDiscount ? (
        <span className="font-semibold text-slate-900">
          {money(price, currency)}
        </span>
      ) : (
        <>
          {/* ✅ Discounted price (price - discount) */}
          <span className="font-semibold text-slate-900">
            {money(
              discount.type === "percentage"
                ? price - (price * discount.value) / 100
                : price - discount.value,
              currency,
            )}
          </span>

          {/* ✅ Original price (slashed) */}
          <span className="text-xs text-slate-500 line-through">
            {money(price, currency)}
          </span>

          {/* Discount label */}
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 border border-emerald-200">
            {discount.type === "percentage"
              ? `-${discount.value}%`
              : `-${money(discount.value, currency)}`}
          </span>
        </>
      )}

      <span className="text-[10px] text-slate-400">
        (new price first, old price slashed)
      </span>
    </div>
  );
};

export default function AddProduct() {
  const [loading, setLoading] = useState(false);
  const [images, setImages] = useState([]);

  const [form, setForm] = useState({
    name: "",
    description: "",
    category: "ring",
    price: "",
    stock: "",
    metalType: "",
    gender: "unisex",
    isFeatured: false,
    currency: "USD",
  });

  // ✅ Discount form state
  const [discountForm, setDiscountForm] = useState({
    isActive: false,
    type: "percentage", // "percentage" | "flat"
    value: "",
    startsAt: "",
    endsAt: "",
  });

  const imagePreviews = useMemo(() => {
    return images.map((file) => URL.createObjectURL(file));
  }, [images]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleDiscountChange = (e) => {
    const { name, value, type, checked } = e.target;
    setDiscountForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleImageChange = (e) => {
    setImages(Array.from(e.target.files || []));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const data = new FormData();

      Object.entries(form).forEach(([key, value]) => {
        if (typeof value === "boolean")
          data.append(key, value ? "true" : "false");
        else data.append(key, value);
      });

      images.forEach((img) => data.append("images", img));

      // ✅ Build discount payload
      // If not active OR no value, send as inactive default object (so backend stores it)
      const discountPayload = {
        isActive: Boolean(discountForm.isActive),
        type: discountForm.type,
        value:
          discountForm.value !== "" && discountForm.value !== null
            ? Number(discountForm.value)
            : 0,
        startsAt: discountForm.startsAt
          ? new Date(discountForm.startsAt).toISOString()
          : null,
        endsAt: discountForm.endsAt
          ? new Date(discountForm.endsAt).toISOString()
          : null,
      };

      // Always send it so backend can store a discount object
      data.append("discount", JSON.stringify(discountPayload));

      await api.post("/api/admin/products", data, {
        headers: { "Content-Type": "multipart/form-data" },
        withCredentials: true,
      });

      alert("✅ Product added successfully");

      setForm({
        name: "",
        description: "",
        category: "ring",
        price: "",
        stock: "",
        metalType: "",
        gender: "unisex",
        isFeatured: false,
        currency: "USD",
      });

      setDiscountForm({
        isActive: false,
        type: "percentage",
        value: "",
        startsAt: "",
        endsAt: "",
      });

      setImages([]);
    } catch (err) {
      alert(err.response?.data?.error || "Failed to add product");
    } finally {
      setLoading(false);
    }
  };

  const clearForm = () => {
    setForm({
      name: "",
      description: "",
      category: "ring",
      price: "",
      stock: "",
      metalType: "",
      gender: "unisex",
      isFeatured: false,
      currency: "USD",
    });

    setDiscountForm({
      isActive: false,
      type: "percentage",
      value: "",
      startsAt: "",
      endsAt: "",
    });

    setImages([]);
  };

  return (
    <div className="min-h-[calc(100vh-60px)] bg-slate-50 px-4 py-8">
      <div className="mx-auto w-full max-w-5xl">
        {/* Header */}
        <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-xl font-semibold tracking-tight text-slate-900">
              Add New Product
            </h1>
            <p className="mt-1 text-sm text-slate-600">
              Create a new jewelry item with images, pricing, and details ✨
            </p>
          </div>

          <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 shadow-sm">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            Admin
          </div>
        </div>

        {/* Card */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Top Grid */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {/* Name */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-800">
                  Product Name <span className="text-rose-500">*</span>
                </label>
                <input
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  placeholder="e.g. Crystal Bloom Ring"
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
                  required
                />
              </div>

              {/* Category */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-800">
                  Category <span className="text-rose-500">*</span>
                </label>
                <select
                  name="category"
                  value={form.category}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
                >
                  <option value="ring">Ring</option>
                  <option value="bracelet">Bracelet</option>
                  <option value="necklace">Necklace</option>
                  <option value="earring">Earring</option>
                  <option value="anklet">Anklet</option>
                  <option value="watch">Watch</option>
                  <option value="pendant">Pendant</option>
                  <option value="set">Set</option>
                  <option value="other">Other</option>
                </select>
              </div>

              {/* Price */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-800">
                  Price <span className="text-rose-500">*</span>
                </label>
                <input
                  name="price"
                  type="number"
                  value={form.price}
                  onChange={handleChange}
                  placeholder="e.g. 120"
                  min="0"
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
                  required
                />
              </div>

              {/* Currency */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-800">
                  Currency
                </label>
                <select
                  name="currency"
                  value={form.currency}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
                >
                  <option value="USD">USD</option>
                  <option value="NGN">NGN</option>
                  <option value="GBP">GBP</option>
                  <option value="EUR">EUR</option>
                </select>
              </div>

              {/* Stock */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-800">
                  Stock
                </label>
                <input
                  name="stock"
                  type="number"
                  value={form.stock}
                  onChange={handleChange}
                  placeholder="e.g. 15"
                  min="0"
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
                />
              </div>

              {/* Metal Type */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-800">
                  Metal Type
                </label>
                <input
                  name="metalType"
                  value={form.metalType}
                  onChange={handleChange}
                  placeholder="e.g. gold, silver, stainless steel"
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
                />
              </div>

              {/* Gender */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-800">
                  Gender
                </label>
                <select
                  name="gender"
                  value={form.gender}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
                >
                  <option value="unisex">Unisex</option>
                  <option value="mens">Men</option>
                  <option value="womens">Women</option>
                </select>
              </div>
            </div>

            {/* ✅ Discount Section */}
            <div className="rounded-2xl border border-slate-200 bg-white p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <div className="text-sm font-semibold text-slate-900">
                    Discount
                  </div>
                  <div className="text-xs text-slate-500">
                    Show new price + slashed old price automatically
                  </div>
                </div>

                <label className="flex items-center gap-3 text-sm text-slate-800">
                  <input
                    type="checkbox"
                    name="isActive"
                    checked={discountForm.isActive}
                    onChange={handleDiscountChange}
                    className="h-4 w-4 rounded border-slate-300 text-slate-900 focus:ring-slate-300"
                  />
                  <span className="font-medium">Enable discount</span>
                </label>
              </div>

              <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-800">
                    Type
                  </label>
                  <select
                    name="type"
                    value={discountForm.type}
                    onChange={handleDiscountChange}
                    disabled={!discountForm.isActive}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition disabled:opacity-60 focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
                  >
                    <option value="percentage">Percentage (%)</option>
                    <option value="flat">Flat amount</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-800">
                    Value
                  </label>
                  <input
                    name="value"
                    type="number"
                    value={discountForm.value}
                    onChange={handleDiscountChange}
                    disabled={!discountForm.isActive}
                    placeholder={
                      discountForm.type === "percentage"
                        ? "e.g. 20"
                        : "e.g. 5000"
                    }
                    min="0"
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition disabled:opacity-60 focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
                  />
                  <div className="text-[11px] text-slate-500">
                    {discountForm.type === "percentage"
                      ? "Example: 20 means 20% off"
                      : "Example: 5000 means remove 5000 from old price"}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-800">
                    Starts At (optional)
                  </label>
                  <input
                    name="startsAt"
                    type="datetime-local"
                    value={discountForm.startsAt}
                    onChange={handleDiscountChange}
                    disabled={!discountForm.isActive}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition disabled:opacity-60 focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
                    placeholder={toISODateTimeLocalValue()}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-800">
                    Ends At (optional)
                  </label>
                  <input
                    name="endsAt"
                    type="datetime-local"
                    value={discountForm.endsAt}
                    onChange={handleDiscountChange}
                    disabled={!discountForm.isActive}
                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition disabled:opacity-60 focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
                    placeholder={toISODateTimeLocalValue()}
                  />
                </div>
              </div>

              <div className="mt-4">
                <PricePreview
                  price={form.price}
                  currency={form.currency}
                  discount={{ ...discountForm, currency: form.currency }}
                />
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-800">
                Description
              </label>
              <textarea
                name="description"
                value={form.description}
                onChange={handleChange}
                rows={5}
                placeholder="Write a short description that sells the vibe..."
                className="w-full resize-y rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none transition focus:border-slate-400 focus:ring-4 focus:ring-slate-200"
              />
            </div>

            {/* Featured + Upload */}
            <div className="flex flex-col gap-3 rounded-2xl border border-dashed border-slate-200 bg-slate-50 p-4 sm:flex-row sm:items-center sm:justify-between">
              {/* Featured */}
              <label className="flex items-center gap-3 text-sm text-slate-800">
                <input
                  type="checkbox"
                  name="isFeatured"
                  checked={form.isFeatured}
                  onChange={handleChange}
                  className="h-4 w-4 rounded border-slate-300 text-slate-900 focus:ring-slate-300"
                />
                <span className="font-medium">
                  Feature this product{" "}
                  <span className="ml-1 text-xs font-normal text-slate-500">
                    (shows on featured list)
                  </span>
                </span>
              </label>

              {/* Upload */}
              <div className="flex items-center gap-3">
                <input
                  id="images"
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                />
                <label
                  htmlFor="images"
                  className="inline-flex cursor-pointer items-center justify-center rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-800 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md active:translate-y-0"
                >
                  Choose Images
                </label>
                <span className="text-xs text-slate-600">
                  {images.length
                    ? `${images.length} selected`
                    : "PNG/JPG (max 6)"}
                </span>
              </div>
            </div>

            {/* Previews */}
            {imagePreviews.length > 0 && (
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <p className="text-sm font-medium text-slate-800">
                    Image Preview
                  </p>
                  <p className="text-xs text-slate-500">
                    First image becomes{" "}
                    <span className="font-semibold">Primary</span>
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
                  {imagePreviews.map((src, idx) => (
                    <div
                      key={src}
                      className="relative overflow-hidden rounded-2xl border border-slate-200 bg-white aspect-square"
                    >
                      <img
                        src={src}
                        alt={`preview-${idx}`}
                        className="h-full w-full object-cover"
                      />
                      {idx === 0 && (
                        <span className="absolute bottom-2 left-2 rounded-full bg-slate-900/85 px-2 py-1 text-[10px] font-semibold text-white">
                          Primary
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={clearForm}
                disabled={loading}
                className="inline-flex items-center justify-center rounded-xl border border-slate-200 bg-slate-100 px-4 py-2.5 text-sm font-semibold text-slate-800 transition hover:bg-slate-200 disabled:opacity-60"
              >
                Clear
              </button>

              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center justify-center rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-md active:translate-y-0 disabled:opacity-60"
              >
                {loading ? "Uploading..." : "Add Product"}
              </button>
            </div>
          </form>
        </div>

        {/* Tiny footer hint */}
        <p className="mt-4 text-center text-xs text-slate-500">
          Tip: Use sharp, bright photos — jewelry loves light 😄✨
        </p>
      </div>
    </div>
  );
}
