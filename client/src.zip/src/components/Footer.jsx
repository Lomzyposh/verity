import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer
      className="pt-12 border-t bg-[#e7e7fa]"
      style={{ borderColor: "#E5E7EB" }}
    >
      <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-4 gap-12">
        {/* BRAND */}
        <div>
          <div className="flex items-center mb-3">
            <img
              src="/images/logo.png"
              alt="Verity Gem"
              className="h-8 w-auto"
            />
            <h2 className="text-xl font-semibold" style={{ color: "#111827" }}>
              Verity<span style={{ color: "#2563EB" }}>Gem</span>
            </h2>
          </div>

          <p className="mb-4" style={{ color: "#6B7280" }}>
            Timeless jewelry crafted with elegance, precision and heart.
          </p>

          {/* ADDRESS */}
          <p className="text-sm leading-relaxed" style={{ color: "#6B7280" }}>
            📍 1600 West Slauson Ave
            <br />
            Booth B2
            <br />
            Los Angeles, CA 90047
          </p>
        </div>

        {/* SHOP */}
        <div>
          <h3 className="font-semibold mb-3" style={{ color: "#111827" }}>
            Shop
          </h3>
          <ul className="space-y-2">
            <FooterLink to="/shop?category=watch" label="Watches" />
            <FooterLink to="/shop?category=ring" label="Rings" />
            <FooterLink to="/shop?category=necklace" label="Necklaces" />
            <FooterLink to="/shop?category=bracelet" label="Bracelets" />
            <FooterLink to="/shop?category=earring" label="Earrings" />
          </ul>
        </div>

        {/* CUSTOMER CARE */}
        <div>
          <h3 className="font-semibold mb-3" style={{ color: "#111827" }}>
            Support
          </h3>
          <ul className="space-y-2">
            <FooterLink to="/contact" label="Contact" />
            {/* <FooterLink to="/" label="Shipping & Returns" />
            <FooterLink to="/" label="Size Guide" />
             */}
            <FooterLink to="/faq" label="FAQ" />
          </ul>
        </div>

        {/* SOCIALS */}
        <div>
          <h3 className="font-semibold mb-3" style={{ color: "#111827" }}>
            Connect
          </h3>
          <ul className="space-y-2">
            <FooterLink
              to="https://instagram.com/veritygemjewelry"
              label="Instagram"
            />
            <FooterLink to="https://tiktok.com/@veritygem" label="TikTok" />
            <FooterLink
              to="https://web.facebook.com/profile.php?id=61585657743953"
              label="Facebook"
            />
          </ul>
        </div>
      </div>

      {/* COPYRIGHT */}
      <div
        className="mt-12 py-6 text-center border-t"
        style={{ borderColor: "#E5E7EB" }}
      >
        <p className="text-sm" style={{ color: "#6B7280" }}>
          © {new Date().getFullYear()} VerityGem. All rights reserved.
        </p>
      </div>
    </footer>
  );
}

function FooterLink({ to, label }) {
  return (
    <li>
      <Link
        to={to}
        className="hover:underline transition-colors"
        style={{ color: "#6B7280" }}
        onMouseEnter={(e) => (e.currentTarget.style.color = "#2563EB")}
        onMouseLeave={(e) => (e.currentTarget.style.color = "#6B7280")}
      >
        {label}
      </Link>
    </li>
  );
}
